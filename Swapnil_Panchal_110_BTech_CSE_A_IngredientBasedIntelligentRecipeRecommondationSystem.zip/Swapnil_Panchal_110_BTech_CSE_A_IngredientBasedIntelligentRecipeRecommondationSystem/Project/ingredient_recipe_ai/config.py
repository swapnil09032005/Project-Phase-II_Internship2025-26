"""
Application configuration.

This file keeps environment loading and database selection in one place so the
project is easy to explain during a viva or project demo.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from urllib.parse import unquote

from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from sqlalchemy.exc import OperationalError


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
MYSQL_IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9_]+$")


def _normalize_password(password: str) -> str:
    """Accept raw or URL-encoded passwords from the environment."""

    if re.search(r"%[0-9A-Fa-f]{2}", password):
        return unquote(password)
    return password


def _build_mysql_url(database_name: str | None = None) -> URL | None:
    """Create a MySQL connection string when all required values exist."""

    host = os.getenv("DB_HOST")
    port = os.getenv("DB_PORT", "3306")
    user = os.getenv("DB_USER")
    password = os.getenv("DB_PASSWORD")
    env_database_name = os.getenv("DB_NAME")

    required_values = [host, user, password]
    if database_name is None:
        required_values.append(env_database_name)

    if not all(required_values):
        return None

    selected_database = env_database_name if database_name is None else database_name
    return URL.create(
        "mysql+pymysql",
        username=user,
        password=_normalize_password(password),
        host=host,
        port=int(port),
        database=selected_database or None,
    )


def _render_url(url: URL) -> str:
    """Convert a SQLAlchemy URL into the string form Flask expects."""

    return url.render_as_string(hide_password=False)


def _verify_mysql_connection(url: URL) -> None:
    """Raise if a MySQL connection cannot be established."""

    engine = create_engine(url, pool_pre_ping=True, connect_args={"connect_timeout": 3})
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))


def _is_unknown_database_error(error: OperationalError) -> bool:
    """Return True when MySQL reports that DB_NAME does not exist yet."""

    original_error = getattr(error, "orig", None)
    if getattr(original_error, "args", None):
        return original_error.args[0] == 1049
    return "unknown database" in str(error).lower()


def _quote_mysql_identifier(identifier: str) -> str:
    """Safely quote a MySQL identifier for DDL statements."""

    if not MYSQL_IDENTIFIER_PATTERN.fullmatch(identifier):
        raise ValueError("DB_NAME may only contain letters, numbers, and underscores.")
    return f"`{identifier}`"


def _create_mysql_database_if_missing(database_name: str) -> None:
    """Create the configured MySQL database if the server is reachable."""

    server_url = _build_mysql_url(database_name="")
    if server_url is None:
        raise ValueError("MySQL credentials are incomplete.")

    engine = create_engine(server_url, pool_pre_ping=True, connect_args={"connect_timeout": 3})
    with engine.begin() as connection:
        connection.execute(
            text(
                "CREATE DATABASE IF NOT EXISTS "
                f"{_quote_mysql_identifier(database_name)} "
                "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
        )


def choose_database_uri() -> tuple[str, str, str]:
    """
    Prefer MySQL when credentials are present and the server is reachable.

    If the connection fails, the app automatically switches to SQLite so the
    project can still run on any machine for development or demonstrations.
    """

    sqlite_path = BASE_DIR / "ingredient_recipe_ai.db"
    sqlite_uri = f"sqlite:///{sqlite_path.as_posix()}"

    mysql_url = _build_mysql_url()
    if not mysql_url:
        return sqlite_uri, "SQLite fallback", "MySQL credentials not found; using local SQLite."

    try:
        _verify_mysql_connection(mysql_url)
        return _render_url(mysql_url), "MySQL", "Connected to the configured MySQL database."
    except OperationalError as exc:
        if _is_unknown_database_error(exc):
            try:
                database_name = os.getenv("DB_NAME", "")
                _create_mysql_database_if_missing(database_name)
                _verify_mysql_connection(mysql_url)
                return (
                    _render_url(mysql_url),
                    "MySQL",
                    "Created the configured MySQL database and connected successfully.",
                )
            except Exception:
                pass
        return sqlite_uri, "SQLite fallback", "MySQL was unavailable; switched to SQLite automatically."
    except Exception:
        return sqlite_uri, "SQLite fallback", "MySQL was unavailable; switched to SQLite automatically."


class Config:
    """Main Flask configuration object."""

    SQLALCHEMY_DATABASE_URI, DATABASE_LABEL, DATABASE_STATUS = choose_database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}
    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key")
    PORT = int(os.getenv("PORT", "5001"))
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", str(BASE_DIR / "uploads"))
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024
    TESSERACT_CMD = os.getenv("TESSERACT_CMD", "")
    ML_CONFIDENCE_THRESHOLD = float(os.getenv("ML_CONFIDENCE_THRESHOLD", "40"))
    ML_MODEL_DIR = BASE_DIR / "ml" / "models"
    ML_DATASET_PATH = BASE_DIR / "data" / "recipes.csv"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
