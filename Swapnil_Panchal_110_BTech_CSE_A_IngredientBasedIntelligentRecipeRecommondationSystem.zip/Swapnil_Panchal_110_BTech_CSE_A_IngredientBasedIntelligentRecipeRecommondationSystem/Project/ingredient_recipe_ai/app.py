"""
Main entry point for the Ingredient-Based Intelligent Recipe Generator.

The app factory pattern is used here because it keeps the setup modular and
easy to explain. Each feature area is placed in its own route or service file.
"""

from __future__ import annotations

import logging
import os

from flask import Flask, g

from config import Config
from ml.model_loader import ModelNotReadyError, load_model
from models import db
from routes.auth_routes import auth_bp
from routes.ingredient_routes import ingredient_bp
from routes.page_routes import page_bp
from routes.recipe_routes import recipe_bp
from services.auth_service import get_current_user
from services.localization_service import (
    SUPPORTED_LANGUAGES,
    get_client_messages,
    get_current_language,
    get_speech_locale,
    translate_text,
)
from services.catalog_sync_service import sync_recipe_catalog


logger = logging.getLogger(__name__)


def create_app() -> Flask:
    """Create and configure the Flask application."""

    app = Flask(__name__)
    app.config.from_object(Config)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    os.makedirs(app.config["ML_MODEL_DIR"], exist_ok=True)

    db.init_app(app)

    app.register_blueprint(page_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(ingredient_bp)
    app.register_blueprint(recipe_bp)

    with app.app_context():
        db.create_all()
        sync_recipe_catalog()
        try:
            load_model()
        except ModelNotReadyError as exc:
            logger.warning("ML model preload skipped: %s", exc)

    @app.before_request
    def load_logged_in_user() -> None:
        """Attach the current user to Flask's `g` object for every request."""

        g.current_user = get_current_user()
        g.current_language = get_current_language()

    @app.context_processor
    def inject_global_template_data() -> dict:
        """Share common template values across all pages."""

        return {
            "current_user": getattr(g, "current_user", None),
            "current_language": getattr(g, "current_language", "en"),
            "language_options": SUPPORTED_LANGUAGES,
            "database_label": app.config["DATABASE_LABEL"],
            "database_status": app.config["DATABASE_STATUS"],
            "speech_locale": get_speech_locale(getattr(g, "current_language", "en")),
            "client_messages": get_client_messages(getattr(g, "current_language", "en")),
            "t": lambda key, **kwargs: translate_text(
                key,
                getattr(g, "current_language", "en"),
                **kwargs,
            ),
        }

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True, port=app.config["PORT"])
