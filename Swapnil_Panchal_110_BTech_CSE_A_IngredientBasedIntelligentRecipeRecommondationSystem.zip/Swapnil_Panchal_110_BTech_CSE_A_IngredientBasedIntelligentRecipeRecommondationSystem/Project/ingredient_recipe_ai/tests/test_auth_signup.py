"""Regression tests for duplicate signup handling."""

from __future__ import annotations

import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app import create_app
from services.auth_service import DuplicateEmailError, create_user


class SignupTests(unittest.TestCase):
    """Protect the signup flow against duplicate-email failures."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app()
        cls.app.testing = True

    def setUp(self) -> None:
        self.client = self.app.test_client()

    def test_create_user_rolls_back_cleanly_after_duplicate_email(self) -> None:
        """The session should stay usable when the database rejects a duplicate email."""

        first_email = f"signup-duplicate-{uuid.uuid4().hex[:10]}@example.com"
        second_email = f"signup-recovery-{uuid.uuid4().hex[:10]}@example.com"

        with self.app.app_context():
            create_user("First User", first_email, "Password123!")

            with self.assertRaises(DuplicateEmailError):
                create_user("Second User", first_email, "Password123!")

            recovered_user = create_user("Recovery User", second_email, "Password123!")
            self.assertIsNotNone(recovered_user.id)

    def test_signup_returns_conflict_when_duplicate_email_race_reaches_service(self) -> None:
        """The route should not crash if the duplicate is detected during commit."""

        payload = {
            "full_name": "Race Condition User",
            "email": f"signup-race-{uuid.uuid4().hex[:10]}@example.com",
            "password": "Password123!",
        }

        with patch(
            "routes.auth_routes.create_user",
            side_effect=DuplicateEmailError(payload["email"]),
        ):
            response = self.client.post("/signup", json=payload)

        self.assertEqual(response.status_code, 409)
        self.assertEqual(
            response.get_json(),
            {
                "success": False,
                "message": "An account with this email already exists.",
            },
        )
