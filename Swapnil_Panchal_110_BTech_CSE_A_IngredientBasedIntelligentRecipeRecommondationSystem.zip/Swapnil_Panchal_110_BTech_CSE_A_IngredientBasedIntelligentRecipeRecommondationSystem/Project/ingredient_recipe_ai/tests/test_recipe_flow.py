"""Regression tests for dataset-backed recipe matching."""

from __future__ import annotations

import unittest
import uuid
from pathlib import Path

import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app import create_app
from services.ingredient_service import normalize_ingredient_input


RAW_INGREDIENT_INPUT = (
    '["4 cups low-sodium vegetable or chicken stock", '
    '"1 cup dried brown lentils", '
    '"1/2 cup dried French green lentils", '
    '"2 stalks celery, chopped", '
    '"1 large carrot, peeled and chopped", '
    '"1 sprig fresh thyme", '
    '"1 teaspoon kosher salt", '
    '"1 medium tomato, cored, seeded, and diced", '
    '"1 small Fuji apple, cored and diced", '
    '"1 tablespoon freshly squeezed lemon juice", '
    '"2 teaspoons extra-virgin olive oil", '
    '"Freshly ground black pepper to taste", '
    '"3 sheets whole-wheat lavash, cut in half crosswise, or 6 (12-inch) flour tortillas", '
    '"3/4 pound turkey breast, thinly sliced", '
    '"1/2 head Bibb lettuce"]'
)

EXPECTED_TITLE = "Lentil, Apple, and Turkey Wrap"


class RecipeFlowTests(unittest.TestCase):
    """End-to-end checks for the imported real recipe catalog."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app()
        cls.app.testing = True

    def setUp(self) -> None:
        self.client = self.app.test_client()
        signup_response = self.client.post(
            "/signup",
            json={
                "full_name": "Regression Test User",
                "email": f"recipe-flow-{uuid.uuid4().hex[:10]}@example.com",
                "password": "Regression123!",
            },
        )
        self.assertEqual(signup_response.status_code, 201)

    def test_dataset_style_ingredient_input_is_parsed_into_match_terms(self) -> None:
        """Pasted ingredient arrays should normalize into usable tokens."""

        ingredients = normalize_ingredient_input(RAW_INGREDIENT_INPUT)

        for expected_term in (
            "stock",
            "lentil",
            "tomato",
            "apple",
            "olive oil",
            "lavash",
            "tortilla",
            "turkey",
            "lettuce",
        ):
            self.assertIn(expected_term, ingredients)

    def test_matching_dataset_recipe_is_top_recommendation(self) -> None:
        """The imported wrap recipe should be the top recommendation."""

        response = self.client.post(
            "/api/recommend",
            json={"ingredients": RAW_INGREDIENT_INPUT},
        )
        payload = response.get_json()

        self.assertEqual(response.status_code, 200)
        self.assertTrue(payload["success"])
        self.assertEqual(payload["source"], "ml")
        self.assertEqual(payload["recipes"][0]["name"], EXPECTED_TITLE)
        self.assertEqual(payload["recipes"][0]["score"], 100.0)

    def test_saved_recipe_appears_on_dashboard(self) -> None:
        """A recommended imported recipe should be saveable like any other recipe."""

        recommend_response = self.client.post(
            "/api/recommend",
            json={"ingredients": RAW_INGREDIENT_INPUT},
        )
        recipe_id = recommend_response.get_json()["recipes"][0]["recipe_id"]

        save_response = self.client.post("/save-recipe", json={"recipe_id": recipe_id})
        dashboard_response = self.client.get("/dashboard")

        self.assertEqual(save_response.status_code, 200)
        self.assertTrue(save_response.get_json()["success"])
        self.assertIn(EXPECTED_TITLE, dashboard_response.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
