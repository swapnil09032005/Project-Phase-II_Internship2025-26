"""Unit tests for database selection and MySQL URL building."""

from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import config
from sqlalchemy.exc import OperationalError


class ConfigTests(unittest.TestCase):
    """Protect MySQL-first configuration behavior."""

    def test_build_mysql_url_decodes_percent_encoded_password(self) -> None:
        """The .env password may be URL-encoded and should still work."""

        with patch.dict(
            "os.environ",
            {
                "DB_HOST": "127.0.0.1",
                "DB_PORT": "3306",
                "DB_USER": "root",
                "DB_PASSWORD": "Swapnil%402026%3F%3F",
                "DB_NAME": "ingredient_recipe",
            },
            clear=False,
        ):
            url = config._build_mysql_url()

        self.assertIsNotNone(url)
        self.assertEqual(url.password, "Swapnil@2026??")

    def test_choose_database_uri_creates_missing_mysql_database(self) -> None:
        """A missing MySQL schema should be created instead of forcing SQLite."""

        unknown_database_error = OperationalError(
            "SELECT 1",
            {},
            Exception(1049, "Unknown database 'ingredient_recipe'"),
        )

        with patch.dict(
            "os.environ",
            {
                "DB_HOST": "127.0.0.1",
                "DB_PORT": "3306",
                "DB_USER": "root",
                "DB_PASSWORD": "Swapnil%402026%3F%3F",
                "DB_NAME": "ingredient_recipe",
            },
            clear=False,
        ):
            with patch.object(
                config,
                "_verify_mysql_connection",
                side_effect=[unknown_database_error, None],
            ) as verify_connection:
                with patch.object(config, "_create_mysql_database_if_missing") as create_database:
                    uri, label, status = config.choose_database_uri()

        self.assertTrue(uri.startswith("mysql+pymysql://root:"))
        self.assertEqual(label, "MySQL")
        self.assertEqual(
            status,
            "Created the configured MySQL database and connected successfully.",
        )
        self.assertEqual(verify_connection.call_count, 2)
        create_database.assert_called_once_with("ingredient_recipe")
