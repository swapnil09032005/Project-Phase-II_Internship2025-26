"""Routes that render the main HTML pages."""

from __future__ import annotations

from urllib.parse import urlsplit

from flask import Blueprint, g, redirect, render_template, request, session, url_for

from models import SavedRecipe
from services.auth_service import login_required
from services.ingredient_service import normalize_ingredient_input, normalize_ingredient_list
from services.localization_service import (
    localize_ingredient,
    localize_recipe_payload,
    set_current_language,
)
from services.hybrid_recommendation_service import get_recommendation_payloads
from services.recipe_service import build_recipe_payload, get_recent_recipes


page_bp = Blueprint("page", __name__)


def _safe_internal_redirect_target(target: str | None) -> str:
    """Allow redirects only to local application paths."""

    if not target:
        return url_for("page.index")

    parsed_target = urlsplit(target)
    if parsed_target.scheme or parsed_target.netloc:
        return url_for("page.index")

    path = parsed_target.path or "/"
    if not path.startswith("/"):
        return url_for("page.index")

    if parsed_target.query:
        return f"{path}?{parsed_target.query}"
    return path


@page_bp.route("/")
def index():
    """Landing page."""

    if g.current_user:
        return redirect(url_for("page.upload_page"))

    return render_template("index.html")


@page_bp.route("/set-language", methods=["POST"])
def set_language():
    """Store the user's preferred language in the session."""

    set_current_language(request.form.get("language"))
    next_page = _safe_internal_redirect_target(
        request.form.get("next") or request.referrer
    )
    return redirect(next_page)


@page_bp.route("/upload")
@login_required
def upload_page():
    """Ingredient upload page."""

    return render_template("upload.html")


@page_bp.route("/ingredients")
@login_required
def ingredients_page():
    """Ingredient review page with editable tags."""

    raw_ingredients = request.args.get("ingredients", "")
    if raw_ingredients:
        ingredients = normalize_ingredient_input(raw_ingredients)
    else:
        ingredients = normalize_ingredient_list(request.args.getlist("ingredient"))
        if not ingredients:
            ingredients = normalize_ingredient_list(session.get("last_ingredients", []))

    return render_template("ingredients.html", ingredients=ingredients)


@page_bp.route("/results")
@login_required
def results_page():
    """Results page that shows ranked recipes."""

    ingredients = normalize_ingredient_input(request.args.get("ingredients", ""))
    ranked_recipes = get_recommendation_payloads(ingredients) if ingredients else []
    localized_recipes = [
        localize_recipe_payload(recipe, g.current_language)
        for recipe in ranked_recipes
    ]
    display_ingredients = [
        localize_ingredient(item, g.current_language)
        for item in ingredients
    ]
    return render_template(
        "results.html",
        ingredients=ingredients,
        display_ingredients=display_ingredients,
        recipes=localized_recipes,
    )


@page_bp.route("/dashboard")
@login_required
def dashboard():
    """User dashboard with saved and recent recipes."""

    saved_entries = (
        SavedRecipe.query.filter_by(user_id=g.current_user.id)
        .order_by(SavedRecipe.created_at.desc())
        .all()
    )
    saved_recipes = [
        localize_recipe_payload(build_recipe_payload(entry.recipe), g.current_language)
        for entry in saved_entries
        if entry.recipe
    ]
    recent_recipes = [
        localize_recipe_payload(build_recipe_payload(recipe), g.current_language)
        for recipe in get_recent_recipes(g.current_user.id)
    ]

    return render_template(
        "dashboard.html",
        saved_recipes=saved_recipes,
        recent_recipes=recent_recipes,
    )
