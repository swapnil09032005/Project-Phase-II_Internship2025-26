"""Routes for recipe recommendation, detail view, and save feature."""

from __future__ import annotations

from flask import Blueprint, g, jsonify, render_template, request, url_for

from services.auth_service import api_login_required, login_required
from services.hybrid_recommendation_service import (
    get_recommendation_payloads,
    get_recommendations,
)
from services.ingredient_service import normalize_ingredient_input
from services.localization_service import (
    get_speech_locale,
    get_voice_commands,
    localize_recipe_payload,
    translate_text,
)
from services.recipe_service import (
    build_recipe_payload,
    get_recipe_by_id,
    save_recipe_for_user,
    track_recent_recipe,
)


recipe_bp = Blueprint("recipe", __name__)


@recipe_bp.route("/recommend-recipes", methods=["POST"])
@recipe_bp.route("/api/recommend", methods=["POST"])
@api_login_required
def recommend_recipes_api():
    """Return strict hybrid recipe recommendations as JSON."""

    payload = request.get_json(silent=True) if request.is_json else request.form
    ingredients = payload.get("ingredients", [])

    normalized_ingredients = normalize_ingredient_input(ingredients)
    if not normalized_ingredients:
        return jsonify({"success": False, "message": "Please provide at least one ingredient."}), 400

    recommendations = get_recommendations(normalized_ingredients)
    return jsonify(
        {
            "success": True,
            "ingredients": normalized_ingredients,
            "recipes": recommendations,
            "source": recommendations[0].get("source") if recommendations else None,
        }
    )


@recipe_bp.route("/recipe/<int:recipe_id>")
@login_required
def recipe_detail(recipe_id: int):
    """Show one recipe in detail or return it as JSON."""

    selected_ingredients = normalize_ingredient_input(request.args.get("ingredients", ""))
    source = request.args.get("source", "")
    selected_score = request.args.get("score", type=float)
    recipe = get_recipe_by_id(recipe_id)

    if recipe is None:
        return render_template("404.html"), 404

    track_recent_recipe(recipe.id)
    payload = localize_recipe_payload(
        build_recipe_payload(recipe, selected_ingredients),
        g.current_language,
    )
    if selected_score is not None:
        payload["match_score"] = round(selected_score, 2)
    else:
        recommendations = get_recommendation_payloads(selected_ingredients) if selected_ingredients else []
        selected_payload = next((item for item in recommendations if item["id"] == recipe.id), None)
        if selected_payload is not None:
            payload["match_score"] = selected_payload["match_score"]
            payload["source"] = selected_payload.get("source")
    guide_config = {
        "recipeTitle": payload["title"],
        "ingredients": payload["ingredients"],
        "steps": payload["guide_steps"],
        "speechLocale": get_speech_locale(g.current_language),
        "voiceCommands": get_voice_commands(g.current_language),
        "stepOfTemplate": translate_text("recipe.guide.step_of", g.current_language),
    }

    if request.args.get("format") == "json":
        return jsonify({"success": True, "recipe": payload, "guide_config": guide_config})

    if selected_ingredients or source == "results":
        back_url = url_for("page.results_page", ingredients=",".join(selected_ingredients))
        back_label = translate_text("recipe.back_to_results", g.current_language)
    elif source == "dashboard":
        back_url = url_for("page.dashboard")
        back_label = translate_text("recipe.back_to_dashboard", g.current_language)
    else:
        back_url = url_for("page.upload_page")
        back_label = translate_text("results.go_upload", g.current_language)

    return render_template(
        "recipe_detail.html",
        recipe=payload,
        selected_ingredients=selected_ingredients,
        guide_config=guide_config,
        back_url=back_url,
        back_label=back_label,
    )


@recipe_bp.route("/save-recipe", methods=["POST"])
@api_login_required
def save_recipe():
    """Bookmark a recipe for the logged-in user."""

    payload = request.get_json(silent=True) if request.is_json else request.form
    recipe_id = payload.get("recipe_id")

    if not recipe_id:
        return jsonify({"success": False, "message": "Recipe id is required."}), 400

    recipe = get_recipe_by_id(int(recipe_id))
    if recipe is None:
        return jsonify({"success": False, "message": "Recipe not found."}), 404

    success, message = save_recipe_for_user(g.current_user.id, recipe.id)
    status_code = 200 if success else 409
    return jsonify({"success": success, "message": message}), status_code
