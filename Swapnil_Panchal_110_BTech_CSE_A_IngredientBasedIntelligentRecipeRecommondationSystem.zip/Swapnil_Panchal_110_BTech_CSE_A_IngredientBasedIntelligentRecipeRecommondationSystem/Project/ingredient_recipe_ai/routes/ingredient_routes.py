"""Routes for manual ingredient extraction and image-based OCR."""

from __future__ import annotations

from flask import Blueprint, jsonify, request, session

from services.auth_service import api_login_required
from services.ingredient_service import (
    coerce_ingredient_values,
    extract_ingredients_from_text,
    normalize_ingredient_list,
)
from services.ocr_service import allowed_file, extract_text_from_image, save_uploaded_image


ingredient_bp = Blueprint("ingredient", __name__)


@ingredient_bp.route("/upload-image", methods=["POST"])
@api_login_required
def upload_image():
    """Upload an image, run OCR, and return normalized ingredients."""

    image = request.files.get("image")
    if image is None or image.filename == "":
        return jsonify({"success": False, "message": "Please choose an image file."}), 400

    if not allowed_file(image.filename):
        return jsonify({"success": False, "message": "Allowed formats: png, jpg, jpeg, webp."}), 400

    file_path = save_uploaded_image(image)
    ocr_result = extract_text_from_image(file_path)

    if not ocr_result["success"]:
        return jsonify(ocr_result), 400

    manual_text = (request.form.get("manual_text") or "").strip()
    combined_text = "\n".join(part for part in [ocr_result["text"], manual_text] if part)
    ingredients = extract_ingredients_from_text(combined_text)
    session["last_ingredients"] = ingredients

    return jsonify(
        {
            "success": True,
            "message": "Ingredients extracted successfully.",
            "raw_text": ocr_result["text"],
            "ingredients": ingredients,
            "image_path": file_path,
        }
    )


@ingredient_bp.route("/extract-ingredients", methods=["POST"])
@api_login_required
def extract_ingredients():
    """Normalize manual ingredient text and return clean ingredient names."""

    payload = request.get_json(silent=True) if request.is_json else request.form
    raw_text = (payload.get("text") or "").strip()
    ingredient_list = payload.get("ingredients", [])

    ingredient_list = coerce_ingredient_values(ingredient_list)

    combined_ingredients = extract_ingredients_from_text(raw_text)
    combined_ingredients.extend(ingredient_list)
    normalized_items = normalize_ingredient_list(combined_ingredients)

    if not normalized_items:
        return jsonify({"success": False, "message": "No valid ingredients were found."}), 400

    session["last_ingredients"] = normalized_items
    return jsonify(
        {
            "success": True,
            "message": "Ingredients prepared successfully.",
            "ingredients": normalized_items,
        }
    )
