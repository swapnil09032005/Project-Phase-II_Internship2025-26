"""Authentication routes for signup, login, and logout."""

from __future__ import annotations

from flask import Blueprint, flash, jsonify, redirect, render_template, request, url_for

from models import User
from services.auth_service import (
    DuplicateEmailError,
    authenticate_user,
    create_user,
    login_user,
    logout_user,
)


auth_bp = Blueprint("auth", __name__)


def _wants_json_response() -> bool:
    return request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest"


def _duplicate_email_response():
    """Return the standard response for duplicate signup attempts."""

    message = "An account with this email already exists."
    if _wants_json_response():
        return jsonify({"success": False, "message": message}), 409
    flash(message, "warning")
    return redirect(url_for("auth.signup"))


@auth_bp.route("/signup", methods=["GET", "POST"])
def signup():
    """Register a new user account."""

    if request.method == "GET":
        return render_template("signup.html")

    payload = request.get_json(silent=True) if request.is_json else request.form
    full_name = (payload.get("full_name") or "").strip()
    email = (payload.get("email") or "").strip().lower()
    password = (payload.get("password") or "").strip()

    if not all([full_name, email, password]):
        message = "Full name, email, and password are required."
        if _wants_json_response():
            return jsonify({"success": False, "message": message}), 400
        flash(message, "danger")
        return redirect(url_for("auth.signup"))

    if User.query.filter_by(email=email).first():
        return _duplicate_email_response()

    try:
        user = create_user(full_name, email, password)
    except DuplicateEmailError:
        return _duplicate_email_response()

    login_user(user)

    if _wants_json_response():
        return jsonify({"success": True, "message": "Signup successful."}), 201

    flash("Account created successfully.", "success")
    return redirect(url_for("page.dashboard"))


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """Log in an existing user."""

    if request.method == "GET":
        return render_template("login.html")

    payload = request.get_json(silent=True) if request.is_json else request.form
    email = (payload.get("email") or "").strip().lower()
    password = (payload.get("password") or "").strip()

    user = authenticate_user(email, password)
    if not user:
        message = "Invalid email or password."
        if _wants_json_response():
            return jsonify({"success": False, "message": message}), 401
        flash(message, "danger")
        return redirect(url_for("auth.login"))

    login_user(user)

    if _wants_json_response():
        return jsonify({"success": True, "message": "Login successful."})

    flash("Welcome back.", "success")
    next_page = request.args.get("next") or payload.get("next") or url_for("page.dashboard")
    return redirect(next_page)


@auth_bp.route("/logout", methods=["POST", "GET"])
def logout():
    """Log out the current user."""

    logout_user()

    if _wants_json_response():
        return jsonify({"success": True, "message": "Logged out successfully."})

    flash("You have been logged out.", "info")
    return redirect(url_for("page.index"))
