"""
Optional helper script for manual database initialization.

Running this file rebuilds the application's own tables and inserts sample
data. This is useful when an older MySQL schema already exists, because
`create_all()` does not update incompatible tables automatically.
"""

from app import create_app
from models import db
from services.catalog_sync_service import sync_recipe_catalog
from sqlalchemy import inspect, text


app = create_app()


def reset_current_database() -> None:
    """
    Drop every existing table in the currently selected database.

    This is more reliable than `db.drop_all()` when old tables from previous
    project versions still exist and contain foreign-key references that are
    unknown to the new SQLAlchemy metadata.
    """

    engine = db.engine
    dialect_name = engine.dialect.name
    inspector = inspect(engine)
    table_names = inspector.get_table_names()

    if not table_names:
        return

    with engine.begin() as connection:
        if dialect_name == "mysql":
            connection.execute(text("SET FOREIGN_KEY_CHECKS = 0"))
            for table_name in table_names:
                connection.execute(text(f"DROP TABLE IF EXISTS `{table_name}`"))
            connection.execute(text("SET FOREIGN_KEY_CHECKS = 1"))
            return

        if dialect_name == "sqlite":
            connection.execute(text("PRAGMA foreign_keys = OFF"))
            for table_name in table_names:
                if table_name == "sqlite_sequence":
                    continue
                connection.execute(text(f'DROP TABLE IF EXISTS "{table_name}"'))
            connection.execute(text("PRAGMA foreign_keys = ON"))
            return

        db.drop_all()


with app.app_context():
    # Start fresh so old tables from earlier experiments do not conflict with
    # the new beginner-friendly schema used by this project.
    reset_current_database()
    db.create_all()
    sync_recipe_catalog()
    print("Database initialized successfully with a clean schema.")
