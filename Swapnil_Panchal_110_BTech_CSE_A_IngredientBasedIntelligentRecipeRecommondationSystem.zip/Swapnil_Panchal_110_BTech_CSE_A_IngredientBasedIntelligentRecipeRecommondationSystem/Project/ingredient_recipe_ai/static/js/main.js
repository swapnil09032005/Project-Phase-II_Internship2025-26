/*
    Client-side interactions for upload, ingredient editing, saving recipes,
    AR-style cooking guidance, and voice navigation.
*/

document.addEventListener("DOMContentLoaded", () => {
    initializeToasts();
    initializeUploadForm();
    initializeIngredientEditor();
    initializeIngredientVoiceInput();
    initializeSaveButtons();
    initializeModalControls();
    initializeRecipeGuide();
});

function getAppMessage(key, fallback) {
    return window.appConfig?.messages?.[key] || fallback;
}

function showToast(message, kind = "success") {
    const container = document.getElementById("toast-container");
    if (!container) {
        return;
    }

    const toast = document.createElement("div");
    toast.className = "toast-card pointer-events-auto rounded-2xl border border-white/70 bg-white/90 px-4 py-3 shadow-lg";
    toast.dataset.kind = kind;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3500);
}

function initializeToasts() {
    const toasts = document.querySelectorAll(".toast-card");
    toasts.forEach((toast) => {
        setTimeout(() => {
            toast.remove();
        }, 3500);
    });
}

function initializeUploadForm() {
    const form = document.getElementById("upload-form");
    if (!form) {
        return;
    }

    const fileInput = document.getElementById("image");
    const manualText = document.getElementById("manual_text");
    const preview = document.getElementById("image-preview");
    const loaderPanel = document.getElementById("loader-panel");

    fileInput.addEventListener("change", () => {
        const file = fileInput.files[0];
        if (!file) {
            preview.classList.add("hidden");
            return;
        }

        preview.src = URL.createObjectURL(file);
        preview.classList.remove("hidden");
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const file = fileInput.files[0];
        const textValue = manualText.value.trim();

        if (!file && !textValue) {
            showToast(
                getAppMessage(
                    "client.upload_or_type",
                    "Please upload an image or type ingredients first."
                ),
                "warning"
            );
            return;
        }

        loaderPanel.classList.remove("hidden");

        try {
            let responseData;

            if (file) {
                const formData = new FormData();
                formData.append("image", file);
                formData.append("manual_text", textValue);

                const response = await fetch("/upload-image", {
                    method: "POST",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: formData
                });
                if (response.status === 401) {
                    handleUnauthorized();
                    return;
                }
                responseData = await response.json();
            } else {
                const response = await fetch("/extract-ingredients", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: JSON.stringify({ text: textValue })
                });
                if (response.status === 401) {
                    handleUnauthorized();
                    return;
                }
                responseData = await response.json();
            }

            if (!responseData.success) {
                showToast(
                    responseData.message ||
                        getAppMessage("client.extract_failed", "Unable to extract ingredients."),
                    "danger"
                );
                loaderPanel.classList.add("hidden");
                return;
            }

            const ingredients = (responseData.ingredients || []).join(",");
            window.location.href = `/ingredients?ingredients=${encodeURIComponent(ingredients)}`;
        } catch (error) {
            showToast(
                getAppMessage(
                    "client.request_failed",
                    "Something went wrong while processing the request."
                ),
                "danger"
            );
            loaderPanel.classList.add("hidden");
        }
    });
}

function getSpeechRecognitionConstructor() {
    return window.SpeechRecognition || window.webkitSpeechRecognition || null;
}

function getSpeechLocale() {
    return window.appConfig?.speechLocale || "en-IN";
}

function createSpeechInputController({
    button,
    statusElement,
    onFinalTranscript
}) {
    const SpeechRecognition = getSpeechRecognitionConstructor();
    let recognition = null;
    let isListening = false;

    function setButtonLabel(listening) {
        if (!button) {
            return;
        }

        button.textContent = listening
            ? button.dataset.stopLabel
            : button.dataset.startLabel;
    }

    function setStatus(listening) {
        if (!statusElement) {
            return;
        }

        statusElement.textContent = listening
            ? statusElement.dataset.listeningText
            : statusElement.dataset.idleText;
    }

    function handleUnsupported() {
        showToast(
            getAppMessage(
                "client.ingredient_voice_unsupported",
                "Voice ingredient input is not supported in this browser."
            ),
            "warning"
        );
    }

    function ensureRecognition() {
        if (!SpeechRecognition) {
            return null;
        }

        if (recognition) {
            return recognition;
        }

        recognition = new SpeechRecognition();
        recognition.lang = getSpeechLocale();
        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onresult = (event) => {
            const finalChunks = [];

            for (let index = event.resultIndex; index < event.results.length; index += 1) {
                const result = event.results[index];
                const transcript = result?.[0]?.transcript?.trim();
                if (!transcript) {
                    continue;
                }

                if (result.isFinal) {
                    finalChunks.push(transcript);
                }
            }

            if (finalChunks.length > 0) {
                onFinalTranscript(finalChunks.join(" "));
            }
        };

        recognition.onerror = (event) => {
            if (event.error === "not-allowed" || event.error === "service-not-allowed") {
                isListening = false;
                setButtonLabel(false);
                setStatus(false);
                showToast(
                    getAppMessage(
                        "client.ingredient_voice_denied",
                        "Microphone access was blocked. Please allow it in your browser settings to use voice ingredient input."
                    ),
                    "warning"
                );
                return;
            }

            if (event.error === "aborted") {
                return;
            }

            isListening = false;
            setButtonLabel(false);
            setStatus(false);
        };

        recognition.onend = () => {
            if (!isListening) {
                setButtonLabel(false);
                setStatus(false);
                return;
            }

            try {
                recognition.start();
            } catch (error) {
                isListening = false;
                setButtonLabel(false);
                setStatus(false);
            }
        };

        return recognition;
    }

    function start() {
        if (!SpeechRecognition) {
            handleUnsupported();
            return;
        }

        const speechRecognition = ensureRecognition();
        if (!speechRecognition) {
            return;
        }

        isListening = true;
        speechRecognition.lang = getSpeechLocale();

        try {
            speechRecognition.start();
            setButtonLabel(true);
            setStatus(true);
            showToast(
                getAppMessage(
                    "client.ingredient_voice_started",
                    "Voice ingredient input is listening."
                ),
                "success"
            );
        } catch (error) {
            handleUnsupported();
        }
    }

    function stop(silent = false) {
        isListening = false;

        if (recognition) {
            try {
                recognition.stop();
            } catch (error) {
                // Recognition may already be idle.
            }
        }

        setButtonLabel(false);
        setStatus(false);

        if (!silent) {
            showToast(
                getAppMessage(
                    "client.ingredient_voice_stopped",
                    "Voice ingredient input stopped."
                ),
                "info"
            );
        }
    }

    function toggle() {
        if (isListening) {
            stop();
            return;
        }
        start();
    }

    setButtonLabel(false);
    setStatus(false);

    return {
        start,
        stop,
        toggle
    };
}

function splitSpokenIngredients(transcript) {
    return String(transcript || "")
        .split(/[\n,;]| and /i)
        .map((item) => item.trim().toLowerCase())
        .filter(Boolean);
}

function appendTranscriptToTextArea(textArea, transcript) {
    const trimmedTranscript = String(transcript || "").trim();
    if (!trimmedTranscript) {
        showToast(
            getAppMessage(
                "client.ingredient_voice_empty",
                "No ingredient words were captured. Please try again."
            ),
            "warning"
        );
        return;
    }

    const existingValue = textArea.value.trim();
    const separator = existingValue && !/[,\n;]\s*$/.test(existingValue) ? ", " : "";
    textArea.value = `${existingValue}${separator}${trimmedTranscript}`.trim();
    showToast(
        getAppMessage(
            "client.ingredient_voice_added",
            "Spoken ingredients were added."
        ),
        "success"
    );
}

function initializeIngredientVoiceInput() {
    const uploadVoiceButton = document.getElementById("voice-ingredient-button");
    const uploadVoiceStatus = document.getElementById("voice-ingredient-status");
    const manualText = document.getElementById("manual_text");

    if (uploadVoiceButton && uploadVoiceStatus && manualText) {
        const uploadVoiceController = createSpeechInputController({
            button: uploadVoiceButton,
            statusElement: uploadVoiceStatus,
            onFinalTranscript: (transcript) => {
                appendTranscriptToTextArea(manualText, transcript);
            }
        });

        uploadVoiceButton.addEventListener("click", () => {
            uploadVoiceController.toggle();
        });
    }
}

function initializeIngredientEditor() {
    const tagContainer = document.getElementById("ingredient-tags");
    if (!tagContainer) {
        return;
    }

    const hiddenField = document.getElementById("ingredients-hidden");
    const inputField = document.getElementById("new-ingredient");
    const addButton = document.getElementById("add-ingredient-button");
    const voiceAddButton = document.getElementById("voice-add-ingredient-button");
    const voiceAddStatus = document.getElementById("voice-add-status");
    const form = document.getElementById("ingredients-form");

    let ingredients = Array.isArray(window.initialIngredients) ? [...window.initialIngredients] : [];

    function addIngredients(values) {
        values.forEach((value) => {
            const cleanedValue = value.trim().toLowerCase();
            if (!cleanedValue || ingredients.includes(cleanedValue)) {
                return;
            }
            ingredients.push(cleanedValue);
        });
    }

    function renderTags() {
        tagContainer.innerHTML = "";

        if (ingredients.length === 0) {
            const emptyState = document.createElement("p");
            emptyState.className = "text-slate-500";
            emptyState.textContent =
                window.ingredientEditorEmptyState || "No ingredients yet. Add some to continue.";
            tagContainer.appendChild(emptyState);
        }

        ingredients.forEach((ingredient, index) => {
            const tag = document.createElement("span");
            tag.className = "tag-chip";
            tag.innerHTML = `
                <span>${ingredient}</span>
                <button type="button" class="tag-remove" data-index="${index}">&times;</button>
            `;
            tagContainer.appendChild(tag);
        });

        hiddenField.value = ingredients.join(",");
    }

    addButton.addEventListener("click", () => {
        const value = inputField.value.trim().toLowerCase();
        if (!value) {
            return;
        }
        addIngredients([value]);
        inputField.value = "";
        renderTags();
    });

    inputField.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            addButton.click();
        }
    });

    tagContainer.addEventListener("click", (event) => {
        const target = event.target;
        if (!(target instanceof HTMLElement)) {
            return;
        }

        const index = target.dataset.index;
        if (index === undefined) {
            return;
        }

        ingredients.splice(Number(index), 1);
        renderTags();
    });

    form.addEventListener("submit", (event) => {
        if (ingredients.length === 0) {
            event.preventDefault();
            showToast(
                getAppMessage(
                    "client.add_ingredient_first",
                    "Add at least one ingredient before continuing."
                ),
                "warning"
            );
        }
    });

    if (voiceAddButton && voiceAddStatus) {
        const voiceAddController = createSpeechInputController({
            button: voiceAddButton,
            statusElement: voiceAddStatus,
            onFinalTranscript: (transcript) => {
                const spokenIngredients = splitSpokenIngredients(transcript);
                if (spokenIngredients.length === 0) {
                    showToast(
                        getAppMessage(
                            "client.ingredient_voice_empty",
                            "No ingredient words were captured. Please try again."
                        ),
                        "warning"
                    );
                    return;
                }

                addIngredients(spokenIngredients);
                inputField.value = "";
                renderTags();
                showToast(
                    getAppMessage(
                        "client.ingredient_voice_added",
                        "Spoken ingredients were added."
                    ),
                    "success"
                );
            }
        });

        voiceAddButton.addEventListener("click", () => {
            voiceAddController.toggle();
        });
    }

    renderTags();
}

function initializeSaveButtons() {
    const saveButtons = document.querySelectorAll(".save-recipe-button");
    if (saveButtons.length === 0) {
        return;
    }

    saveButtons.forEach((button) => {
        button.addEventListener("click", async () => {
            const recipeId = button.dataset.recipeId;
            if (!recipeId) {
                return;
            }

            try {
                const response = await fetch("/save-recipe", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: JSON.stringify({ recipe_id: recipeId })
                });
                if (response.status === 401) {
                    handleUnauthorized();
                    return;
                }
                const data = await response.json();
                showToast(
                    data.message ||
                        getAppMessage("client.request_completed", "Request completed."),
                    data.success ? "success" : "warning"
                );
            } catch (error) {
                showToast(
                    getAppMessage(
                        "client.save_failed",
                        "Unable to save this recipe right now."
                    ),
                    "danger"
                );
            }
        });
    });
}

function initializeModalControls() {
    const openButtons = document.querySelectorAll("[data-open-modal]");
    const closeButtons = document.querySelectorAll("[data-close-modal]");

    openButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const modal = document.getElementById(button.dataset.openModal);
            if (modal) {
                modal.classList.remove("hidden");
            }
        });
    });

    closeButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const modal = document.getElementById(button.dataset.closeModal);
            if (modal) {
                modal.classList.add("hidden");
            }
        });
    });
}

function initializeRecipeGuide() {
    const config = window.recipeGuideConfig;
    const root = document.getElementById("recipe-guide");
    if (!root || !config || !Array.isArray(config.steps) || config.steps.length === 0) {
        return;
    }

    const steps = config.steps;
    const progressLabel = document.getElementById("guide-progress");
    const stepTitle = document.getElementById("guide-step-title");
    const stepInstruction = document.getElementById("guide-step-instruction");
    const focusArea = document.getElementById("guide-focus-area");
    const focusCopy = document.getElementById("guide-focus-copy");
    const voiceHint = document.getElementById("guide-voice-hint");
    const overlay = document.getElementById("ar-guide-overlay");
    const stepCards = document.querySelectorAll("[data-guide-step-card]");

    const prevButton = document.getElementById("guide-prev-button");
    const nextButton = document.getElementById("guide-next-button");
    const speakButton = document.getElementById("guide-speak-button");
    const cameraButton = document.getElementById("guide-camera-button");
    const voiceButton = document.getElementById("guide-voice-button");

    const video = document.getElementById("ar-guide-video");
    const idlePanel = document.getElementById("guide-camera-idle");

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    let currentIndex = 0;
    let mediaStream = null;
    let recognition = null;
    let isListening = false;

    function formatStepProgress() {
        const template = config.stepOfTemplate || "Step {current} of {total}";
        return template
            .replace("{current}", String(currentIndex + 1))
            .replace("{total}", String(steps.length));
    }

    function updateStepCards() {
        stepCards.forEach((card, index) => {
            card.classList.toggle("guide-step-card-active", index === currentIndex);
        });
    }

    function updateStepUI() {
        const step = steps[currentIndex];
        progressLabel.textContent = formatStepProgress();
        stepTitle.textContent = step.title;
        stepInstruction.textContent = step.instruction;
        focusArea.textContent = step.display_focus_area || step.focus_area || "";
        focusCopy.textContent = step.display_focus_area || step.focus_area || "";
        voiceHint.textContent = step.voice_hint || "";
        overlay.dataset.anchor = step.overlay_anchor || "center";

        prevButton.disabled = currentIndex === 0;
        nextButton.disabled = currentIndex === steps.length - 1;
        prevButton.classList.toggle("opacity-60", currentIndex === 0);
        nextButton.classList.toggle("opacity-60", currentIndex === steps.length - 1);

        updateStepCards();
    }

    function speakText(text) {
        if (!window.speechSynthesis || !text) {
            return;
        }

        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = config.speechLocale || "en-IN";
        utterance.rate = 0.96;
        window.speechSynthesis.speak(utterance);
    }

    function speakCurrentStep() {
        const step = steps[currentIndex];
        speakText(`${config.recipeTitle}. ${step.title}. ${step.instruction}`);
    }

    function speakIngredients() {
        const ingredients = Array.isArray(config.ingredients) ? config.ingredients.join(", ") : "";
        speakText(`${config.recipeTitle}. ${ingredients}`);
    }

    function goToNextStep() {
        if (currentIndex >= steps.length - 1) {
            return;
        }
        currentIndex += 1;
        updateStepUI();
    }

    function goToPreviousStep() {
        if (currentIndex <= 0) {
            return;
        }
        currentIndex -= 1;
        updateStepUI();
    }

    function setCameraButtonLabel(isActive) {
        cameraButton.textContent = isActive
            ? cameraButton.dataset.stopLabel
            : cameraButton.dataset.startLabel;
    }

    function setVoiceButtonLabel(listening) {
        voiceButton.textContent = listening
            ? voiceButton.dataset.stopLabel
            : voiceButton.dataset.startLabel;
    }

    async function startCamera() {
        if (!navigator.mediaDevices?.getUserMedia) {
            showToast(
                getAppMessage(
                    "client.guide_camera_unsupported",
                    "This browser does not support the cooking camera overlay."
                ),
                "warning"
            );
            return;
        }

        try {
            mediaStream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: { ideal: "environment" }
                },
                audio: false
            });

            video.srcObject = mediaStream;
            video.muted = true;
            video.autoplay = true;
            video.playsInline = true;

            await new Promise((resolve) => {
                if (video.readyState >= 1) {
                    resolve();
                    return;
                }

                const handleLoadedMetadata = () => {
                    video.removeEventListener("loadedmetadata", handleLoadedMetadata);
                    resolve();
                };

                video.addEventListener("loadedmetadata", handleLoadedMetadata, { once: true });
            });

            await video.play();
            idlePanel.classList.add("hidden");
            setCameraButtonLabel(true);
            showToast(
                getAppMessage(
                    "client.guide_camera_started",
                    "Camera overlay is now live."
                ),
                "success"
            );
        } catch (error) {
            showToast(
                getAppMessage(
                    "client.guide_camera_denied",
                    "Camera access was blocked. Please allow it in your browser settings."
                ),
                "warning"
            );
        }
    }

    function stopCamera(silent = false) {
        if (mediaStream) {
            mediaStream.getTracks().forEach((track) => track.stop());
            mediaStream = null;
        }

        if (video) {
            video.srcObject = null;
        }

        idlePanel.classList.remove("hidden");
        setCameraButtonLabel(false);

        if (!silent) {
            showToast(
                getAppMessage(
                    "client.guide_camera_stopped",
                    "Camera overlay stopped."
                ),
                "info"
            );
        }
    }

    function matchesVoiceCommand(transcript, phrases) {
        if (!Array.isArray(phrases)) {
            return false;
        }
        return phrases.some((phrase) => transcript.includes(String(phrase).toLowerCase()));
    }

    function handleVoiceCommand(transcript) {
        const normalizedTranscript = transcript.toLowerCase().trim();
        const voiceCommands = config.voiceCommands || {};

        if (matchesVoiceCommand(normalizedTranscript, voiceCommands.next)) {
            goToNextStep();
            speakCurrentStep();
            return;
        }

        if (matchesVoiceCommand(normalizedTranscript, voiceCommands.previous)) {
            goToPreviousStep();
            speakCurrentStep();
            return;
        }

        if (matchesVoiceCommand(normalizedTranscript, voiceCommands.repeat)) {
            speakCurrentStep();
            return;
        }

        if (matchesVoiceCommand(normalizedTranscript, voiceCommands.ingredients)) {
            speakIngredients();
            return;
        }

        if (matchesVoiceCommand(normalizedTranscript, voiceCommands.stop)) {
            stopVoiceAssistant();
        }
    }

    function buildRecognition() {
        if (!SpeechRecognition) {
            return null;
        }

        const instance = new SpeechRecognition();
        instance.lang = config.speechLocale || "en-IN";
        instance.continuous = true;
        instance.interimResults = false;

        instance.onresult = (event) => {
            const result = event.results[event.results.length - 1];
            if (!result?.[0]?.transcript) {
                return;
            }
            handleVoiceCommand(result[0].transcript);
        };

        instance.onerror = (event) => {
            if (event.error === "not-allowed" || event.error === "service-not-allowed") {
                isListening = false;
                setVoiceButtonLabel(false);
                showToast(
                    getAppMessage(
                        "client.guide_voice_denied",
                        "Microphone access was blocked. Please allow it in your browser settings."
                    ),
                    "warning"
                );
            }
        };

        instance.onend = () => {
            if (!isListening) {
                return;
            }

            try {
                instance.start();
            } catch (error) {
                isListening = false;
                setVoiceButtonLabel(false);
            }
        };

        return instance;
    }

    function startVoiceAssistant() {
        if (!SpeechRecognition) {
            showToast(
                getAppMessage(
                    "client.guide_voice_unsupported",
                    "Speech recognition is not supported in this browser."
                ),
                "warning"
            );
            return;
        }

        if (!recognition) {
            recognition = buildRecognition();
        }

        if (!recognition) {
            return;
        }

        isListening = true;
        recognition.lang = config.speechLocale || "en-IN";

        try {
            recognition.start();
            setVoiceButtonLabel(true);
            showToast(
                getAppMessage(
                    "client.guide_voice_started",
                    "Voice assistant is listening for commands."
                ),
                "success"
            );
        } catch (error) {
            showToast(
                getAppMessage(
                    "client.guide_voice_unsupported",
                    "Speech recognition is not supported in this browser."
                ),
                "warning"
            );
        }
    }

    function stopVoiceAssistant(silent = false) {
        isListening = false;

        if (recognition) {
            try {
                recognition.stop();
            } catch (error) {
                // No extra handling is needed when recognition is already idle.
            }
        }

        setVoiceButtonLabel(false);

        if (!silent) {
            showToast(
                getAppMessage(
                    "client.guide_voice_stopped",
                    "Voice assistant stopped."
                ),
                "info"
            );
        }
    }

    prevButton.addEventListener("click", goToPreviousStep);
    nextButton.addEventListener("click", goToNextStep);
    speakButton.addEventListener("click", speakCurrentStep);

    cameraButton.addEventListener("click", async () => {
        if (mediaStream) {
            stopCamera();
            return;
        }
        await startCamera();
    });

    voiceButton.addEventListener("click", () => {
        if (isListening) {
            stopVoiceAssistant();
            return;
        }
        startVoiceAssistant();
    });

    window.addEventListener("beforeunload", () => {
        stopCamera(true);
        stopVoiceAssistant(true);
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
    });

    updateStepUI();
}

function handleUnauthorized() {
    showToast(
        getAppMessage(
            "client.auth_required",
            "Please sign up or log in to continue."
        ),
        "warning"
    );
    setTimeout(() => {
        window.location.href = "/login";
    }, 800);
}
