"""Image upload, OpenCV preprocessing, and Tesseract OCR helpers."""

from __future__ import annotations

import os
from pathlib import Path
from uuid import uuid4

import cv2
import pytesseract
from flask import current_app
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename


ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def allowed_file(filename: str) -> bool:
    """Check whether the uploaded image uses a supported extension."""

    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_uploaded_image(file_storage: FileStorage) -> str:
    """Store the uploaded file in the configured uploads folder."""

    extension = file_storage.filename.rsplit(".", 1)[1].lower()
    safe_name = secure_filename(file_storage.filename or "ingredient_image")
    unique_name = f"{uuid4().hex}_{safe_name}"
    file_path = Path(current_app.config["UPLOAD_FOLDER"]) / unique_name

    file_storage.save(file_path)
    return str(file_path)


def preprocess_image(image_path: str):
    """
    Clean the image before OCR.

    OpenCV improves OCR quality by converting the image to grayscale, reducing
    noise, and applying thresholding for clearer text extraction.
    """

    image = cv2.imread(image_path)
    if image is None:
        raise ValueError("Unable to read the uploaded image.")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    processed = cv2.adaptiveThreshold(
        blurred,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        11,
        2,
    )
    return processed


def extract_text_from_image(image_path: str) -> dict:
    """Run OCR and return a structured response for the route layer."""

    tesseract_cmd = current_app.config.get("TESSERACT_CMD", "")
    if tesseract_cmd:
        pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

    if tesseract_cmd and not os.path.exists(tesseract_cmd):
        return {
            "success": False,
            "message": "Tesseract path is configured, but the executable was not found.",
            "text": "",
        }

    try:
        processed_image = preprocess_image(image_path)
        text = pytesseract.image_to_string(processed_image, config="--oem 3 --psm 6")
        return {
            "success": True,
            "message": "OCR completed successfully.",
            "text": text.strip(),
        }
    except pytesseract.TesseractNotFoundError:
        return {
            "success": False,
            "message": "Tesseract OCR is not installed on this machine.",
            "text": "",
        }
    except Exception as exc:
        return {
            "success": False,
            "message": f"Unable to process the image: {exc}",
            "text": "",
        }

