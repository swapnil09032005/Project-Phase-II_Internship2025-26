"""Authentication helper functions used by routes and templates."""

from __future__ import annotations

from functools import wraps

from flask import flash, g, jsonify, redirect, request, session, url_for
from sqlalchemy.exc import IntegrityError
from werkzeug.security import check_password_hash, generate_password_hash

from models import User, db


class DuplicateEmailError(ValueError):
    """Raised when signup tries to create an account for an existing email."""

    def __init__(self, email: str) -> None:
        self.email = email
        super().__init__(f"An account with the email '{email}' already exists.")


def _is_duplicate_email_error(error: IntegrityError) -> bool:
    """Identify duplicate-email integrity failures across SQLite and MySQL."""

    error_text = str(getattr(error, "orig", error)).lower()
    return "unique constraint failed: users.email" in error_text or (
        "duplicate entry" in error_text and "email" in error_text
    )


def create_user(full_name: str, email: str, password: str) -> User:
    """Create a new user account with a securely hashed password."""

    normalized_email = email.strip().lower()
    user = User(
        full_name=full_name.strip(),
        email=normalized_email,
        password_hash=generate_password_hash(password),
    )
    db.session.add(user)

    try:
        db.session.commit()
    except IntegrityError as exc:
        db.session.rollback()
        if _is_duplicate_email_error(exc):
            raise DuplicateEmailError(normalized_email) from exc
        raise

    return user


def authenticate_user(email: str, password: str) -> User | None:
    """Check user credentials and return the matching user if valid."""

    user = User.query.filter_by(email=email.strip().lower()).first()
    if user and check_password_hash(user.password_hash, password):
        return user
    return None


def login_user(user: User) -> None:
    """Save the logged-in user's id in the Flask session."""

    session.pop("last_ingredients", None)
    session.pop("recent_recipe_ids", None)
    session["user_id"] = user.id


def logout_user() -> None:
    """Clear session details on logout."""

    session.pop("last_ingredients", None)
    session.pop("recent_recipe_ids", None)
    session.pop("user_id", None)


def get_current_user() -> User | None:
    """Read the current user from session storage."""

    user_id = session.get("user_id")
    if not user_id:
        return None
    return db.session.get(User, user_id)


def api_login_required(view_function):
    """Return a JSON 401 response when an API is called without login."""

    @wraps(view_function)
    def wrapped_view(*args, **kwargs):
        if getattr(g, "current_user", None) is None:
            return (
                jsonify(
                    {
                        "success": False,
                        "message": "Please sign up or log in to use the application.",
                    }
                ),
                401,
            )
        return view_function(*args, **kwargs)

    return wrapped_view


def login_required(view_function):
    """Redirect anonymous users to the login page."""

    @wraps(view_function)
    def wrapped_view(*args, **kwargs):
        if getattr(g, "current_user", None) is None:
            flash("Please sign up or log in to continue.", "warning")
            return redirect(url_for("auth.login", next=request.path))
        return view_function(*args, **kwargs)

    return wrapped_view
