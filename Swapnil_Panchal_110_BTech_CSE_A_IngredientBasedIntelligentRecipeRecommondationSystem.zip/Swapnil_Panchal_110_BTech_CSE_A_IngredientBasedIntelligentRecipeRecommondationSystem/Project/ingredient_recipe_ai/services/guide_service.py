"""Structured cooking-guide helpers for AR, voice, and translated steps."""

from __future__ import annotations

from copy import deepcopy
import re


DEFAULT_GUIDE_LANGUAGE = "en"
SUPPORTED_GUIDE_LANGUAGES = {"en", "hi", "mr"}


_GUIDE_STEP_TEMPLATES = [
    {
        "step_number": 1,
        "focus_area": "prep board",
        "overlay_anchor": "left",
        "translations": {
            "en": {
                "title": "Prep ingredients",
                "instruction": (
                    "Wash, chop, and arrange the ingredients so everything is ready "
                    "before the heat starts."
                ),
                "voice_hint": "Say next step when the ingredients are ready.",
                "focus_area": "prep board",
            },
            "hi": {
                "title": "सामग्री तैयार करें",
                "instruction": (
                    "सारी सामग्री धोकर, काटकर और पास में रख लें ताकि पकाते समय "
                    "रुकना न पड़े।"
                ),
                "voice_hint": "जब तैयारी हो जाए तो 'अगला स्टेप' कहें।",
                "focus_area": "काटने की जगह",
            },
            "mr": {
                "title": "साहित्य तयार करा",
                "instruction": (
                    "सगळे साहित्य धुऊन, चिरून आणि जवळ ठेवा म्हणजे स्वयंपाक करताना "
                    "मधेमधे थांबावे लागणार नाही."
                ),
                "voice_hint": "तयारी झाली की 'पुढची पायरी' म्हणा.",
                "focus_area": "चिरण्याची जागा",
            },
        },
    },
    {
        "step_number": 2,
        "focus_area": "pan",
        "overlay_anchor": "center",
        "translations": {
            "en": {
                "title": "Heat the pan",
                "instruction": (
                    "Warm the pan, add oil or aromatics, and wait for the base to "
                    "become fragrant."
                ),
                "voice_hint": "Say repeat step if you want to hear this again.",
                "focus_area": "pan",
            },
            "hi": {
                "title": "पैन गरम करें",
                "instruction": (
                    "पैन गरम करें, तेल या खुशबूदार सामग्री डालें, और बेस को सुगंधित "
                    "होने दें।"
                ),
                "voice_hint": "फिर से सुनने के लिए 'दोहराएं' कहें।",
                "focus_area": "पैन",
            },
            "mr": {
                "title": "पॅन गरम करा",
                "instruction": (
                    "पॅन गरम करा, तेल किंवा फोडणीचे साहित्य घाला, आणि बेसचा सुगंध "
                    "येतोय का ते पाहा."
                ),
                "voice_hint": "हे पुन्हा ऐकण्यासाठी 'परत सांगा' म्हणा.",
                "focus_area": "पॅन",
            },
        },
    },
    {
        "step_number": 3,
        "focus_area": "stove",
        "overlay_anchor": "center",
        "translations": {
            "en": {
                "title": "Cook the main mix",
                "instruction": (
                    "Add the main ingredients, stir gently, and watch the texture as "
                    "the recipe cooks through."
                ),
                "voice_hint": "Say previous step if you need to go back.",
                "focus_area": "stove",
            },
            "hi": {
                "title": "मुख्य मिश्रण पकाएं",
                "instruction": (
                    "मुख्य सामग्री डालें, धीरे-धीरे चलाएं, और पकते समय बनावट पर "
                    "ध्यान दें।"
                ),
                "voice_hint": "पीछे जाने के लिए 'पिछला स्टेप' कहें।",
                "focus_area": "स्टोव",
            },
            "mr": {
                "title": "मुख्य मिश्रण शिजवा",
                "instruction": (
                    "मुख्य साहित्य घाला, हलक्या हाताने ढवळा, आणि शिजताना पोत कसा "
                    "बदलतोय ते पाहत राहा."
                ),
                "voice_hint": "मागील पायरीसाठी 'मागची पायरी' म्हणा.",
                "focus_area": "स्टोव्ह",
            },
        },
    },
    {
        "step_number": 4,
        "focus_area": "serving bowl",
        "overlay_anchor": "right",
        "translations": {
            "en": {
                "title": "Finish and serve",
                "instruction": (
                    "Adjust the seasoning, turn off the heat, and plate the dish "
                    "while it is fresh and hot."
                ),
                "voice_hint": "Say read ingredients to review the ingredient list.",
                "focus_area": "serving bowl",
            },
            "hi": {
                "title": "अंतिम टच और परोसें",
                "instruction": (
                    "मसाला चखकर ठीक करें, गैस बंद करें, और डिश को गरमागरम परोसें।"
                ),
                "voice_hint": "सामग्री सुनने के लिए 'इंग्रीडिएंट्स पढ़ो' कहें।",
                "focus_area": "सर्विंग बाउल",
            },
            "mr": {
                "title": "शेवटची तयारी आणि सर्व्ह करा",
                "instruction": (
                    "चव पाहून मसाला सांभाळा, गॅस बंद करा, आणि डिश गरम असतानाच "
                    "सर्व्ह करा."
                ),
                "voice_hint": "साहित्य ऐकण्यासाठी 'साहित्य वाचा' म्हणा.",
                "focus_area": "सर्व्हिंग बाउल",
            },
        },
    },
]


def normalize_guide_language(language: str | None) -> str:
    """Return a supported guide language code."""

    if language in SUPPORTED_GUIDE_LANGUAGES:
        return language
    return DEFAULT_GUIDE_LANGUAGE


def generate_guided_cooking_steps(
    recipe_title: str,
    ingredient_names: list[str],
) -> list[dict]:
    """
    Build generic guide steps for a recipe.

    The steps stay intentionally simple so they work for both sample data and
    future recipes without requiring a separate manual authoring tool.
    """

    del recipe_title, ingredient_names

    generated_steps: list[dict] = []
    for template in _GUIDE_STEP_TEMPLATES:
        english_copy = template["translations"]["en"]
        generated_steps.append(
            {
                "step_number": template["step_number"],
                "title": english_copy["title"],
                "instruction": english_copy["instruction"],
                "focus_area": template["focus_area"],
                "overlay_anchor": template["overlay_anchor"],
                "voice_hint": english_copy["voice_hint"],
                "translations": deepcopy(template["translations"]),
            }
        )
    return generated_steps


def _split_instruction_text(instructions: str) -> list[str]:
    """Split plain-text instructions into readable step strings."""

    cleaned = re.sub(r"\s+", " ", instructions or "").strip()
    if not cleaned:
        return []

    numbered_steps = [
        re.sub(r"^\d+\.\s*", "", part).strip()
        for part in re.split(r"(?=\b\d+\.\s)", cleaned)
        if part.strip()
    ]
    if len(numbered_steps) > 1:
        return numbered_steps

    sentence_steps = [
        part.strip()
        for part in re.split(r"(?<=[.!?])\s+(?=[A-Z])", cleaned)
        if part.strip()
    ]
    return sentence_steps if len(sentence_steps) > 1 else [cleaned]


def _build_step_title(step_number: int, instruction: str) -> str:
    """Create a compact title from the beginning of one instruction sentence."""

    words = instruction.strip().split()
    if not words:
        return f"Step {step_number}"

    preview_words = words[:4]
    return " ".join(word.capitalize() for word in preview_words)


def generate_guided_cooking_steps_from_instructions(
    instructions: str,
    recipe_title: str,
    ingredient_names: list[str],
    max_steps: int = 8,
) -> list[dict]:
    """Build guide steps from real recipe instructions when available."""

    del recipe_title, ingredient_names

    instruction_steps = _split_instruction_text(instructions)[:max_steps]
    if not instruction_steps:
        return []

    focus_areas = ["prep board", "pan", "stove", "serving bowl"]
    overlay_anchors = ["left", "center", "center", "right"]
    voice_hints = [
        "Say next step when you are ready to continue.",
        "Say repeat if you want to hear this step again.",
        "Say previous step if you need to go back.",
        "Say read ingredients to review the ingredient list.",
    ]

    generated_steps: list[dict] = []
    for index, instruction in enumerate(instruction_steps, start=1):
        focus_index = min(index - 1, len(focus_areas) - 1)
        generated_steps.append(
            {
                "step_number": index,
                "title": _build_step_title(index, instruction),
                "instruction": instruction,
                "focus_area": focus_areas[focus_index],
                "overlay_anchor": overlay_anchors[focus_index],
                "voice_hint": voice_hints[focus_index],
                "translations": {},
            }
        )

    return generated_steps


def build_instruction_text(guide_steps: list[dict]) -> str:
    """Join structured steps into the plain-text instruction format used elsewhere."""

    return "\n".join(
        f"Step {step['step_number']}: {step['instruction']}"
        for step in sorted(guide_steps, key=lambda item: item["step_number"])
    )


def serialize_guide_step(step) -> dict:
    """Convert a `GuideStep` model instance into a JSON-friendly dictionary."""

    return {
        "id": step.id,
        "step_number": step.step_number,
        "title": step.title,
        "instruction": step.instruction,
        "focus_area": step.focus_area,
        "overlay_anchor": step.overlay_anchor,
        "voice_hint": step.voice_hint,
        "translations": deepcopy(step.translations or {}),
    }


def localize_guide_step(step: dict, language: str | None) -> dict:
    """Return one guide step with translated display text when available."""

    normalized_language = normalize_guide_language(language)
    translations = deepcopy(step.get("translations") or {})
    localized_copy = translations.get(normalized_language, {})

    return {
        **step,
        "title": localized_copy.get("title", step.get("title", "")),
        "instruction": localized_copy.get("instruction", step.get("instruction", "")),
        "voice_hint": localized_copy.get("voice_hint", step.get("voice_hint", "")),
        "display_focus_area": localized_copy.get(
            "focus_area",
            step.get("focus_area", ""),
        ),
    }
