"""Runtime recipe-catalog synchronization helpers."""

from __future__ import annotations

import logging

from sqlalchemy import delete, insert, select

from config import Config
from ml.preprocessing import FULL_FORMAT_JSON_PATH, build_runtime_catalog_dataframe
from models import GuideStep, Ingredient, Recipe, RecipeIngredient, SavedRecipe, db
from services.seed_service import seed_sample_data


logger = logging.getLogger(__name__)

DATASET_SENTINEL_TITLE = "Lentil, Apple, and Turkey Wrap"
MIN_IMPORTED_RECIPE_COUNT = 5000
RECIPE_BATCH_SIZE = 1000
ASSOCIATION_BATCH_SIZE = 5000


def _has_runtime_dataset() -> bool:
    """Return True when the real recipe dataset is available locally."""

    return Config.ML_DATASET_PATH.exists() or FULL_FORMAT_JSON_PATH.exists()


def _database_has_runtime_dataset() -> bool:
    """Detect whether the runtime database already contains imported real recipes."""

    recipe_count = Recipe.query.count()
    if recipe_count < MIN_IMPORTED_RECIPE_COUNT:
        return False

    return (
        Recipe.query.filter_by(title=DATASET_SENTINEL_TITLE).first() is not None
    )


def _clear_recipe_tables() -> None:
    """Remove recipe-related rows while leaving user accounts intact."""

    logger.info("Clearing recipe-related tables before importing the runtime catalog")
    for model in (SavedRecipe, GuideStep, RecipeIngredient, Recipe, Ingredient):
        db.session.execute(delete(model))
    db.session.commit()


def _chunked(values: list[dict], size: int) -> list[list[dict]]:
    """Yield fixed-size chunks from a list of rows."""

    return [values[index:index + size] for index in range(0, len(values), size)]


def _import_runtime_dataset_catalog() -> None:
    """Import the real dataset into the runtime database."""

    catalog_df = build_runtime_catalog_dataframe()
    logger.info("Importing %s recipes from the runtime dataset", len(catalog_df))

    _clear_recipe_tables()

    unique_ingredient_names = sorted(
        {
            ingredient
            for ingredient_list in catalog_df["normalized_ingredients"]
            for ingredient in ingredient_list
            if ingredient
        }
    )

    ingredient_rows = [{"name": ingredient_name} for ingredient_name in unique_ingredient_names]
    for chunk in _chunked(ingredient_rows, RECIPE_BATCH_SIZE):
        db.session.execute(insert(Ingredient), chunk)
    db.session.commit()

    ingredient_id_lookup = {
        name: ingredient_id
        for ingredient_id, name in db.session.execute(
            select(Ingredient.id, Ingredient.name)
        ).all()
    }

    recipe_rows: list[dict] = []
    for row in catalog_df.itertuples(index=False):
        recipe_rows.append(
            {
                "id": int(row.id),
                "title": str(row.title).strip(),
                "description": row.description or "Recipe imported from the recipe dataset.",
                "cooking_time": int(row.cooking_time or 30),
                "servings": int(row.servings or 4),
                "difficulty": row.difficulty or "Medium",
                "instructions": row.instructions or "",
                "image_url": None,
            }
        )

    for chunk in _chunked(recipe_rows, RECIPE_BATCH_SIZE):
        db.session.execute(insert(Recipe), chunk)
    db.session.commit()

    association_rows: list[dict] = []
    for row in catalog_df.itertuples(index=False):
        recipe_id = int(row.id)
        for ingredient_name in row.normalized_ingredients:
            ingredient_id = ingredient_id_lookup.get(ingredient_name)
            if ingredient_id is None:
                continue
            association_rows.append(
                {
                    "recipe_id": recipe_id,
                    "ingredient_id": ingredient_id,
                }
            )

            if len(association_rows) >= ASSOCIATION_BATCH_SIZE:
                db.session.execute(insert(RecipeIngredient), association_rows)
                association_rows.clear()

    if association_rows:
        db.session.execute(insert(RecipeIngredient), association_rows)

    db.session.commit()
    logger.info("Runtime dataset import completed successfully")


def sync_recipe_catalog() -> None:
    """Ensure the application database contains the correct runtime recipe catalog."""

    if not _has_runtime_dataset():
        logger.info("Runtime dataset not available, keeping the built-in demo catalog")
        seed_sample_data()
        return

    if _database_has_runtime_dataset():
        logger.info("Runtime dataset already present in the database")
        return

    _import_runtime_dataset_catalog()
