"""Hybrid recommendation flow: ML similarity first, rule-based fallback second."""

from __future__ import annotations

import logging

from config import Config
from ml.model_loader import ModelNotReadyError
from ml.recommender import get_ml_recommendations
from services.ingredient_service import normalize_ingredient_list
from services.recommendation_service import recommend_recipes
from services.recipe_service import build_recipe_payload, get_recipes_by_ids


logger = logging.getLogger(__name__)

DEFAULT_LIMIT = 6


def _build_rule_based_results(
    normalized_ingredients: list[str],
    limit: int,
) -> list[dict]:
    """Convert fallback payloads into the strict hybrid response shape."""

    fallback_payloads = recommend_recipes(normalized_ingredients, limit=limit)
    return [
        {
            "recipe_id": int(recipe["id"]),
            "name": recipe["title"],
            "score": float(recipe["match_score"]),
            "missing_ingredients": recipe.get("missing_ingredients", []),
            "source": "rule_based",
        }
        for recipe in fallback_payloads
    ]


def _sanitize_strict_results(results: list[dict]) -> list[dict]:
    """Keep only the strict public response fields."""

    return [
        {
            "recipe_id": int(item["recipe_id"]),
            "name": item["name"],
            "score": float(item["score"]),
            "missing_ingredients": item.get("missing_ingredients", []),
            "source": item["source"],
        }
        for item in results
    ]


def _build_payload_results(
    results: list[dict],
    normalized_ingredients: list[str],
) -> list[dict]:
    """Expand strict recommendation rows into the richer UI payload shape."""

    recipes_by_id = get_recipes_by_ids([item["recipe_id"] for item in results])
    payloads: list[dict] = []

    for item in results:
        recipe = recipes_by_id.get(item["recipe_id"])
        if recipe is None:
            continue

        payload = build_recipe_payload(recipe, normalized_ingredients)
        payload["id"] = item["recipe_id"]
        payload["title"] = item["name"]
        payload["match_score"] = max(float(item["score"]), float(payload["raw_match_score"]))
        payload["source"] = item["source"]
        payloads.append(payload)

    return payloads


def get_recommendations(
    user_ingredients: list[str],
    limit: int = DEFAULT_LIMIT,
) -> list[dict]:
    """
    Return strict hybrid recommendations.

    Output format:
    [
        {
            "recipe_id": int,
            "name": str,
            "score": float,
            "missing_ingredients": list,
            "source": "ml" or "rule_based",
        }
    ]
    """

    normalized_ingredients = normalize_ingredient_list(user_ingredients)
    if not normalized_ingredients:
        return []

    try:
        ml_results = get_ml_recommendations(normalized_ingredients, limit=limit)
    except ModelNotReadyError as exc:
        logger.warning("ML model unavailable, using rule-based fallback: %s", exc)
        ml_results = []
    except Exception as exc:
        logger.exception("ML recommendation failure, using rule-based fallback")
        logger.warning("Failure reason: %s", exc)
        ml_results = []

    best_score = ml_results[0]["score"] if ml_results else 0.0
    if best_score >= Config.ML_CONFIDENCE_THRESHOLD:
        logger.info("ML used with top confidence %.2f", best_score)
        return _sanitize_strict_results(ml_results[:limit])

    logger.info(
        "Fallback used because top ML confidence %.2f is below threshold %.2f",
        best_score,
        Config.ML_CONFIDENCE_THRESHOLD,
    )
    return _build_rule_based_results(normalized_ingredients, limit)


def get_recommendation_payloads(
    user_ingredients: list[str],
    limit: int = DEFAULT_LIMIT,
) -> list[dict]:
    """Return the UI-friendly payloads built from the strict hybrid results."""

    normalized_ingredients = normalize_ingredient_list(user_ingredients)
    if not normalized_ingredients:
        return []

    strict_results = get_recommendations(normalized_ingredients, limit=limit)
    return _build_payload_results(strict_results, normalized_ingredients)
