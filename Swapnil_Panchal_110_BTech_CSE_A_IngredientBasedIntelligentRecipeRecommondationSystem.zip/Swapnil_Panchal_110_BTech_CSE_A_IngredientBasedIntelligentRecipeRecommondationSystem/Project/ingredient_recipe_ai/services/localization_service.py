"""Simple localization helpers for English, Hindi, and Marathi UI support."""

from __future__ import annotations

from copy import deepcopy

from flask import session

from services.guide_service import localize_guide_step


DEFAULT_LANGUAGE = "en"
SUPPORTED_LANGUAGES = {
    "en": {"label": "English", "speech_locale": "en-IN"},
    "hi": {"label": "हिंदी", "speech_locale": "hi-IN"},
    "mr": {"label": "मराठी", "speech_locale": "mr-IN"},
}


TRANSLATIONS = {
    "app.name": {
        "en": "Ingredient Recipe AI",
        "hi": "इंग्रीडिएंट रेसिपी एआई",
        "mr": "इंग्रेडिएंट रेसिपी एआय",
    },
    "meta.description": {
        "en": "Generate recipe suggestions from ingredients using OCR, guided cooking, and MySQL with SQLite fallback.",
        "hi": "OCR, गाइडेड कुकिंग और MySQL के साथ SQLite fallback का उपयोग करके सामग्री से रेसिपी सुझाव प्राप्त करें।",
        "mr": "OCR, गाईडेड कुकिंग आणि MySQL सोबत SQLite fallback वापरून साहित्यावरून रेसिपी सुचना मिळवा.",
    },
    "nav.upload": {"en": "Upload", "hi": "अपलोड", "mr": "अपलोड"},
    "nav.results": {"en": "Results", "hi": "परिणाम", "mr": "निकाल"},
    "nav.dashboard": {"en": "Dashboard", "hi": "डैशबोर्ड", "mr": "डॅशबोर्ड"},
    "nav.logout": {"en": "Logout", "hi": "लॉगआउट", "mr": "लॉगआउट"},
    "nav.login": {"en": "Login", "hi": "लॉगिन", "mr": "लॉगिन"},
    "nav.signup": {"en": "Sign Up", "hi": "साइन अप", "mr": "साइन अप"},
    "nav.language": {"en": "Language", "hi": "भाषा", "mr": "भाषा"},
    "footer.stack": {
        "en": "Built with Flask, Tailwind CSS, OpenCV, Tesseract OCR, AR-style guide, voice support, and database fallback support.",
        "hi": "Flask, Tailwind CSS, OpenCV, Tesseract OCR, AR-स्टाइल गाइड, voice support और database fallback support के साथ बनाया गया।",
        "mr": "Flask, Tailwind CSS, OpenCV, Tesseract OCR, AR-style guide, voice support आणि database fallback support सह तयार केलेले.",
    },
    "footer.database_mode": {
        "en": "Current database mode",
        "hi": "वर्तमान डेटाबेस मोड",
        "mr": "सध्याचा डेटाबेस मोड",
    },
    "footer.database_status": {
        "en": "Connection status",
        "hi": "कनेक्शन स्थिति",
        "mr": "कनेक्शन स्थिती",
    },
    "common.back_home": {"en": "Back to Home", "hi": "होम पर वापस", "mr": "मुख्यपृष्ठावर परत"},
    "common.return_home": {"en": "Return Home", "hi": "होम पर लौटें", "mr": "मुख्यपृष्ठावर जा"},
    "common.email": {"en": "Email", "hi": "ईमेल", "mr": "ईमेल"},
    "common.password": {"en": "Password", "hi": "पासवर्ड", "mr": "पासवर्ड"},
    "common.full_name": {"en": "Full Name", "hi": "पूरा नाम", "mr": "पूर्ण नाव"},
    "common.minutes_short": {"en": "mins", "hi": "मिनट", "mr": "मिनिटे"},
    "common.servings": {"en": "servings", "hi": "सर्विंग", "mr": "सर्व्हिंग"},
    "common.match": {"en": "match", "hi": "मैच", "mr": "जुळण"},
    "common.recommendation": {"en": "recommendation", "hi": "recommendation", "mr": "recommendation"},
    "common.saved": {"en": "saved", "hi": "सेव", "mr": "सेव्ह"},
    "common.viewed": {"en": "viewed", "hi": "देखा गया", "mr": "पाहिले"},
    "index.badge": {
        "en": "Smart cooking from what you already have",
        "hi": "जो सामग्री आपके पास है, उसी से स्मार्ट कुकिंग",
        "mr": "तुमच्याकडे असलेल्या साहित्यापासून स्मार्ट कुकिंग",
    },
    "index.title": {
        "en": "Ingredient-Based Intelligent Recipe Generator",
        "hi": "सामग्री-आधारित इंटेलिजेंट रेसिपी जनरेटर",
        "mr": "साहित्य-आधारित इंटेलिजेंट रेसिपी जनरेटर",
    },
    "index.lead": {
        "en": "Upload an ingredient photo or type your available items manually. The system extracts text with OCR, normalizes ingredient names, and recommends the best matching recipes.",
        "hi": "सामग्री की फोटो अपलोड करें या उपलब्ध चीजें मैन्युअली लिखें। सिस्टम OCR से टेक्स्ट निकालता है, सामग्री के नाम साफ करता है, और सबसे उपयुक्त रेसिपी सुझाता है।",
        "mr": "साहित्याचा फोटो अपलोड करा किंवा उपलब्ध साहित्य हाताने लिहा. सिस्टम OCR वापरून मजकूर काढते, साहित्याची नावे स्वच्छ करते आणि सर्वात योग्य रेसिपी सुचवते.",
    },
    "index.notice": {
        "en": "Create an account first, then log in to use recipe recommendations, guided cooking, and saved recipe features.",
        "hi": "रेसिपी सुझाव, गाइडेड कुकिंग और सेव की गई रेसिपी इस्तेमाल करने के लिए पहले अकाउंट बनाएं, फिर लॉगिन करें।",
        "mr": "रेसिपी सुचना, गाईडेड कुकिंग आणि सेव केलेल्या रेसिपी वापरण्यासाठी आधी खाते तयार करा आणि नंतर लॉगिन करा.",
    },
    "index.create_account": {"en": "Create Account", "hi": "अकाउंट बनाएं", "mr": "खाते तयार करा"},
    "index.login": {"en": "Login to Continue", "hi": "आगे बढ़ने के लिए लॉगिन करें", "mr": "पुढे जाण्यासाठी लॉगिन करा"},
    "index.feature.ocr.title": {"en": "OCR", "hi": "OCR", "mr": "OCR"},
    "index.feature.ocr.copy": {
        "en": "OpenCV preprocessing + Tesseract text extraction",
        "hi": "OpenCV preprocessing + Tesseract text extraction",
        "mr": "OpenCV preprocessing + Tesseract text extraction",
    },
    "index.feature.ranking.title": {"en": "Ranking", "hi": "रैंकिंग", "mr": "रँकिंग"},
    "index.feature.ranking.copy": {
        "en": "Recipes sorted by matched ingredients and missing items",
        "hi": "रेसिपी matched ingredients और missing items के आधार पर sorted होती हैं",
        "mr": "रेसिपी जुळलेल्या साहित्य आणि उरलेल्या साहित्यावरून sort केल्या जातात",
    },
    "index.feature.fallback.title": {"en": "Fallback DB", "hi": "Fallback DB", "mr": "Fallback DB"},
    "index.feature.fallback.copy": {
        "en": "Uses MySQL first and switches to SQLite when needed",
        "hi": "पहले MySQL इस्तेमाल होता है और जरूरत पड़ने पर SQLite पर स्विच होता है",
        "mr": "प्रथम MySQL वापरते आणि गरज पडल्यास SQLite वर स्विच करते",
    },
    "index.how.title": {"en": "How the app works", "hi": "ऐप कैसे काम करता है", "mr": "अ‍ॅप कसे काम करते"},
    "index.how.badge": {"en": "Live flow", "hi": "लाइव फ्लो", "mr": "लाईव्ह फ्लो"},
    "index.step1.title": {"en": "Sign up as a new user", "hi": "नए यूज़र की तरह साइन अप करें", "mr": "नवीन वापरकर्ता म्हणून साइन अप करा"},
    "index.step1.copy": {
        "en": "Create an account so the app can save your activity and recipe bookmarks.",
        "hi": "अकाउंट बनाएं ताकि ऐप आपकी गतिविधि और सेव की गई रेसिपी रख सके।",
        "mr": "तुमची activity आणि सेव केलेल्या रेसिपी साठवण्यासाठी खाते तयार करा.",
    },
    "index.step2.title": {"en": "Log in to enter the app", "hi": "ऐप में प्रवेश के लिए लॉगिन करें", "mr": "अ‍ॅपमध्ये जाण्यासाठी लॉगिन करा"},
    "index.step2.copy": {
        "en": "Authenticated users can access upload, results, saved recipes, and dashboard pages.",
        "hi": "लॉगिन किए हुए यूज़र upload, results, saved recipes और dashboard पेज खोल सकते हैं।",
        "mr": "लॉगिन केलेले वापरकर्ते upload, results, saved recipes आणि dashboard पेज वापरू शकतात.",
    },
    "index.step3.title": {"en": "Collect ingredients", "hi": "सामग्री इकट्ठा करें", "mr": "साहित्य गोळा करा"},
    "index.step3.copy": {
        "en": "Upload a grocery image or type ingredients manually after login.",
        "hi": "लॉगिन के बाद किराने की फोटो अपलोड करें या सामग्री टाइप करें।",
        "mr": "लॉगिन झाल्यावर किराण्याचा फोटो अपलोड करा किंवा साहित्य टाइप करा.",
    },
    "index.step4.title": {"en": "Cook with guidance", "hi": "मार्गदर्शन के साथ पकाएं", "mr": "मार्गदर्शनासह स्वयंपाक करा"},
    "index.step4.copy": {
        "en": "The app recommends recipes, then supports AR-style overlays, voice commands, and saved favorites.",
        "hi": "ऐप रेसिपी सुझाता है और फिर AR-स्टाइल overlays, voice commands और saved favorites में मदद करता है।",
        "mr": "अ‍ॅप रेसिपी सुचवते आणि नंतर AR-style overlays, voice commands आणि saved favorites ला मदत करते.",
    },
    "index.card.security.title": {"en": "Secure first step", "hi": "सुरक्षित शुरुआत", "mr": "सुरक्षित सुरुवात"},
    "index.card.security.copy": {
        "en": "Account-based access keeps saved recipes, recent recipes, and personalized cooking tools tied to each user.",
        "hi": "अकाउंट आधारित एक्सेस से saved recipes, recent recipes और personalized cooking tools हर यूज़र से जुड़े रहते हैं।",
        "mr": "Account-based access मुळे saved recipes, recent recipes आणि personalized cooking tools प्रत्येक वापरकर्त्याशी जोडलेले राहतात.",
    },
    "index.card.score.title": {"en": "Match score formula", "hi": "मैच स्कोर फॉर्मूला", "mr": "मॅच स्कोअर फॉर्म्युला"},
    "index.card.score.copy": {
        "en": "Match score = matched ingredients / total recipe ingredients. Higher scores appear first.",
        "hi": "Match score = matched ingredients / total recipe ingredients. अधिक स्कोर वाली रेसिपी पहले दिखती हैं।",
        "mr": "Match score = matched ingredients / total recipe ingredients. जास्त स्कोअर असलेल्या रेसिपी आधी दिसतात.",
    },
    "index.card.database.title": {"en": "Database-ready design", "hi": "डेटाबेस-रेडी डिज़ाइन", "mr": "डेटाबेस-रेडी डिझाइन"},
    "index.card.database.copy": {
        "en": "The app prefers MySQL for primary storage and falls back to SQLite automatically for demos or local runs.",
        "hi": "ऐप primary storage के लिए MySQL को पसंद करता है और demo या local run में अपने-आप SQLite पर जाता है।",
        "mr": "अ‍ॅप primary storage साठी MySQL वापरते आणि demo किंवा local run साठी आपोआप SQLite वापरते.",
    },
    "upload.title": {"en": "Upload or Enter Ingredients", "hi": "सामग्री अपलोड करें या लिखें", "mr": "साहित्य अपलोड करा किंवा लिहा"},
    "upload.lead": {
        "en": "Upload a photo of ingredient labels or type ingredients manually. The system cleans the list before recommendation.",
        "hi": "सामग्री के लेबल की फोटो अपलोड करें या सामग्री मैन्युअली लिखें। सुझाव देने से पहले सिस्टम सूची को साफ करता है।",
        "mr": "साहित्याच्या लेबलचा फोटो अपलोड करा किंवा साहित्य हाताने लिहा. सुचना देण्यापूर्वी सिस्टम यादी स्वच्छ करते.",
    },
    "upload.ocr_flow": {"en": "See OCR Flow", "hi": "OCR फ्लो देखें", "mr": "OCR फ्लो पाहा"},
    "upload.image_label": {"en": "Upload Ingredient Image", "hi": "सामग्री की इमेज अपलोड करें", "mr": "साहित्याचा फोटो अपलोड करा"},
    "upload.drop_title": {"en": "Drop an image here or click to browse", "hi": "इमेज यहां छोड़ें या चुनने के लिए क्लिक करें", "mr": "फोटो येथे सोडा किंवा निवडण्यासाठी क्लिक करा"},
    "upload.drop_copy": {"en": "Supported: PNG, JPG, JPEG, WEBP", "hi": "Supported: PNG, JPG, JPEG, WEBP", "mr": "Supported: PNG, JPG, JPEG, WEBP"},
    "upload.manual_label": {"en": "Manual Ingredients", "hi": "मैन्युअल सामग्री", "mr": "हस्तलिखित साहित्य"},
    "upload.manual_placeholder": {"en": "Example: tomato, onion, garlic, paneer, chili", "hi": "उदाहरण: tomato, onion, garlic, paneer, chili", "mr": "उदाहरण: tomato, onion, garlic, paneer, chili"},
    "upload.voice_title": {"en": "Voice Ingredient Input"},
    "upload.voice_help": {"en": "Speak ingredients like tomato, onion, garlic, paneer, or chili and they will be added to the text box."},
    "upload.voice_start": {"en": "Start Voice Input"},
    "upload.voice_stop": {"en": "Stop Voice Input"},
    "upload.voice_status_idle": {"en": "Voice input is off."},
    "upload.voice_status_listening": {"en": "Listening for ingredient names..."},
    "upload.extract": {"en": "Extract Ingredients", "hi": "सामग्री निकालें", "mr": "साहित्य काढा"},
    "upload.what_happens": {"en": "What happens after upload?", "hi": "अपलोड के बाद क्या होता है?", "mr": "अपलोडनंतर काय होते?"},
    "upload.what_happens_copy": {
        "en": "The app preprocesses the image with OpenCV, reads text with Tesseract OCR, removes noisy quantities, and turns the result into clean ingredient tags.",
        "hi": "ऐप OpenCV से इमेज साफ करता है, Tesseract OCR से टेक्स्ट पढ़ता है, अतिरिक्त मात्रा हटाता है और परिणाम को साफ ingredient tags में बदलता है।",
        "mr": "अ‍ॅप OpenCV ने इमेज स्वच्छ करते, Tesseract OCR ने मजकूर वाचते, अतिरिक्त मात्रा काढते आणि निकाल स्वच्छ ingredient tags मध्ये बदलते.",
    },
    "upload.loader.title": {"en": "Processing ingredients", "hi": "सामग्री प्रोसेस हो रही है", "mr": "साहित्य प्रोसेस होत आहे"},
    "upload.loader.copy": {"en": "Please wait while the app extracts and cleans your ingredient list.", "hi": "कृपया प्रतीक्षा करें, ऐप आपकी सामग्री सूची निकाल और साफ कर रहा है।", "mr": "कृपया थांबा, अ‍ॅप तुमची साहित्य यादी काढून स्वच्छ करत आहे."},
    "upload.modal.title": {"en": "OCR Flow in Simple Words", "hi": "सरल शब्दों में OCR फ्लो", "mr": "सोप्या शब्दांत OCR फ्लो"},
    "ingredients.title": {"en": "Review Extracted Ingredients", "hi": "निकाली गई सामग्री की समीक्षा करें", "mr": "काढलेल्या साहित्याची पाहणी करा"},
    "ingredients.lead": {"en": "Edit the ingredient tags before generating recipe recommendations.", "hi": "रेसिपी सुझाव बनाने से पहले ingredient tags को बदलें।", "mr": "रेसिपी सुचना तयार करण्यापूर्वी ingredient tags बदला."},
    "ingredients.upload_another": {"en": "Upload Another Image", "hi": "दूसरी इमेज अपलोड करें", "mr": "आणखी एक फोटो अपलोड करा"},
    "ingredients.placeholder": {"en": "Add another ingredient manually", "hi": "एक और सामग्री जोड़ें", "mr": "आणखी एक साहित्य जोडा"},
    "ingredients.add": {"en": "Add Ingredient", "hi": "सामग्री जोड़ें", "mr": "साहित्य जोडा"},
    "ingredients.voice_add": {"en": "Voice Add"},
    "ingredients.voice_start": {"en": "Start Voice Add"},
    "ingredients.voice_stop": {"en": "Stop Voice Add"},
    "ingredients.voice_help": {"en": "Speak one or more ingredients to add them directly to the list."},
    "ingredients.voice_status_idle": {"en": "Voice add is off."},
    "ingredients.voice_status_listening": {"en": "Listening and adding spoken ingredients..."},
    "ingredients.recommend": {"en": "Recommend Recipes", "hi": "रेसिपी सुझाएं", "mr": "रेसिपी सुचवा"},
    "ingredients.empty": {"en": "No ingredients yet. Add some to continue.", "hi": "अभी कोई सामग्री नहीं है। आगे बढ़ने के लिए कुछ जोड़ें।", "mr": "अजून साहित्य नाही. पुढे जाण्यासाठी काही जोडा."},
    "results.title": {"en": "Recommended Recipes", "hi": "सुझाई गई रेसिपी", "mr": "सुचवलेल्या रेसिपी"},
    "results.lead": {"en": "The app shows the top 6 recipes using ingredient ranking and a boosted recommendation score for quick browsing.", "hi": "ऐप ingredient ranking और boosted recommendation score का उपयोग करके top 6 recipes दिखाता है।", "mr": "अॅप ingredient ranking आणि boosted recommendation score वापरून top 6 recipes दाखवते."},
    "results.try_new": {"en": "Try New Ingredients", "hi": "नई सामग्री आज़माएं", "mr": "नवीन साहित्य वापरून पाहा"},
    "results.matched": {"en": "Matched ingredients", "hi": "मिली हुई सामग्री", "mr": "जुळलेले साहित्य"},
    "results.missing": {"en": "Missing ingredients", "hi": "कम सामग्री", "mr": "उणीव असलेले साहित्य"},
    "results.view_recipe": {"en": "View Recipe", "hi": "रेसिपी देखें", "mr": "रेसिपी पाहा"},
    "results.save_recipe": {"en": "Save Recipe", "hi": "रेसिपी सेव करें", "mr": "रेसिपी सेव्ह करा"},
    "results.empty_title": {"en": "No ingredients provided yet", "hi": "अभी सामग्री नहीं दी गई", "mr": "अजून साहित्य दिलेले नाही"},
    "results.empty_copy": {"en": "Start from the upload page to extract ingredients and see recommendations.", "hi": "सामग्री निकालने और सुझाव देखने के लिए upload पेज से शुरू करें।", "mr": "साहित्य काढण्यासाठी आणि सुचना पाहण्यासाठी upload पेजपासून सुरू करा."},
    "results.go_upload": {"en": "Go to Upload Page", "hi": "Upload पेज पर जाएं", "mr": "Upload पेजवर जा"},
    "dashboard.title": {"en": "Your Dashboard", "hi": "आपका डैशबोर्ड", "mr": "तुमचा डॅशबोर्ड"},
    "dashboard.lead": {"en": "View your saved recipes and recently opened recipes in one place.", "hi": "अपनी saved recipes और recently opened recipes एक ही जगह देखें।", "mr": "तुमच्या saved recipes आणि recently opened recipes एकाच ठिकाणी पाहा."},
    "dashboard.saved": {"en": "Saved Recipes", "hi": "सेव की गई रेसिपी", "mr": "सेव्ह केलेल्या रेसिपी"},
    "dashboard.recent": {"en": "Recent Recipes", "hi": "हाल की रेसिपी", "mr": "अलिकडील रेसिपी"},
    "dashboard.saved_empty": {"en": "No saved recipes yet. Save a recipe from the results page to see it here.", "hi": "अभी कोई saved recipe नहीं है। Results पेज से रेसिपी सेव करें।", "mr": "अजून saved recipes नाहीत. Results पेजवरून रेसिपी सेव्ह करा."},
    "dashboard.recent_empty": {"en": "Open a recipe detail page and it will appear here automatically.", "hi": "किसी recipe detail पेज को खोलें, वह यहां अपने-आप दिखेगा।", "mr": "एखादे recipe detail पेज उघडा, ते येथे आपोआप दिसेल."},
    "recipe.available_ingredients": {"en": "Available Ingredients", "hi": "उपलब्ध सामग्री", "mr": "उपलब्ध साहित्य"},
    "recipe.missing_ingredients": {"en": "Missing Ingredients", "hi": "कम सामग्री", "mr": "उणीव असलेले साहित्य"},
    "recipe.no_matched": {"en": "No matched ingredients were passed from the results page.", "hi": "Results पेज से कोई matched ingredient नहीं आया।", "mr": "Results पेजवरून जुळलेले साहित्य आले नाही."},
    "recipe.none_missing": {"en": "You already have everything for this recipe.", "hi": "इस रेसिपी के लिए आपके पास सब कुछ है।", "mr": "या रेसिपीसाठी लागणारे सर्व साहित्य तुमच्याकडे आहे."},
    "recipe.ingredients_list": {"en": "Recipe Ingredients", "hi": "रेसिपी सामग्री", "mr": "रेसिपी साहित्य"},
    "recipe.instructions": {"en": "Cooking Instructions", "hi": "कुकिंग निर्देश", "mr": "कुकिंग सूचना"},
    "recipe.save": {"en": "Save Recipe", "hi": "रेसिपी सेव करें", "mr": "रेसिपी सेव्ह करा"},
    "recipe.back_to_results": {"en": "Back to Results"},
    "recipe.back_to_dashboard": {"en": "Back to Dashboard"},
    "recipe.guide.title": {"en": "AR Cooking Guide", "hi": "AR कुकिंग गाइड", "mr": "AR कुकिंग गाईड"},
    "recipe.guide.lead": {"en": "Use the camera overlay, step controls, and voice assistant for hands-free cooking support.", "hi": "हैंड्स-फ्री कुकिंग के लिए कैमरा overlay, step controls और voice assistant का उपयोग करें।", "mr": "हात मोकळे ठेवून स्वयंपाकासाठी camera overlay, step controls आणि voice assistant वापरा."},
    "recipe.guide.focus_label": {"en": "Focus area", "hi": "फोकस एरिया", "mr": "फोकस एरिया"},
    "recipe.guide.voice_hint": {"en": "Voice hint", "hi": "वॉइस संकेत", "mr": "व्हॉइस संकेत"},
    "recipe.guide.camera_idle": {"en": "Live preview is off. Start it on a phone to place the guide over your cooking area.", "hi": "कैमरा preview बंद है। फोन पर इसे शुरू करें ताकि गाइड cooking area पर दिखे।", "mr": "कॅमेरा preview बंद आहे. फोनवर ते सुरू करा म्हणजे guide cooking area वर दिसेल."},
    "recipe.guide.start_camera": {"en": "Start Live Preview", "hi": "कैमरा शुरू करें", "mr": "कॅमेरा सुरू करा"},
    "recipe.guide.stop_camera": {"en": "Stop Live Preview", "hi": "कैमरा बंद करें", "mr": "कॅमेरा बंद करा"},
    "recipe.guide.start_voice": {"en": "Start Voice", "hi": "वॉइस शुरू करें", "mr": "व्हॉइस सुरू करा"},
    "recipe.guide.stop_voice": {"en": "Stop Voice", "hi": "वॉइस बंद करें", "mr": "व्हॉइस बंद करा"},
    "recipe.guide.read_step": {"en": "Read Step", "hi": "स्टेप पढ़ें", "mr": "पायरी वाचा"},
    "recipe.guide.previous": {"en": "Previous", "hi": "पिछला", "mr": "मागील"},
    "recipe.guide.next": {"en": "Next", "hi": "अगला", "mr": "पुढील"},
    "recipe.guide.step_of": {"en": "Step {current} of {total}", "hi": "स्टेप {current} / {total}", "mr": "पायरी {current} / {total}"},
    "recipe.not_found.title": {"en": "Recipe Not Found", "hi": "रेसिपी नहीं मिली", "mr": "रेसिपी सापडली नाही"},
    "recipe.not_found.copy": {"en": "The requested recipe could not be found.", "hi": "मांगी गई रेसिपी नहीं मिली।", "mr": "मागितलेली रेसिपी सापडली नाही."},
    "login.title": {"en": "Login", "hi": "लॉगिन", "mr": "लॉगिन"},
    "login.lead": {"en": "Use your account to save and revisit recipes.", "hi": "रेसिपी सेव और दोबारा देखने के लिए अपना अकाउंट इस्तेमाल करें।", "mr": "रेसिपी सेव्ह करण्यासाठी आणि पुन्हा पाहण्यासाठी तुमचे खाते वापरा."},
    "login.new_user": {"en": "New user?", "hi": "नए यूज़र?", "mr": "नवीन वापरकर्ता?"},
    "login.create_account": {"en": "Create an account", "hi": "अकाउंट बनाएं", "mr": "खाते तयार करा"},
    "signup.title": {"en": "Create Account", "hi": "अकाउंट बनाएं", "mr": "खाते तयार करा"},
    "signup.lead": {"en": "Sign up to save favorite recipes and track your recent cooking ideas.", "hi": "पसंदीदा रेसिपी सेव करने और हाल की cooking ideas रखने के लिए साइन अप करें।", "mr": "आवडत्या रेसिपी सेव्ह करण्यासाठी आणि अलीकडील cooking ideas ठेवण्यासाठी साइन अप करा."},
    "signup.already": {"en": "Already registered?", "hi": "पहले से रजिस्टर हैं?", "mr": "आधीच नोंदणी केली आहे?"},
    "signup.login_here": {"en": "Login here", "hi": "यहां लॉगिन करें", "mr": "येथे लॉगिन करा"},
    "client.upload_or_type": {"en": "Please upload an image or type ingredients first.", "hi": "कृपया पहले इमेज अपलोड करें या सामग्री लिखें।", "mr": "कृपया आधी फोटो अपलोड करा किंवा साहित्य लिहा."},
    "client.extract_failed": {"en": "Unable to extract ingredients.", "hi": "सामग्री निकाली नहीं जा सकी।", "mr": "साहित्य काढता आले नाही."},
    "client.request_failed": {"en": "Something went wrong while processing the request.", "hi": "रिक्वेस्ट प्रोसेस करते समय कुछ गलत हुआ।", "mr": "रिक्वेस्ट प्रोसेस करताना काहीतरी चुकले."},
    "client.add_ingredient_first": {"en": "Add at least one ingredient before continuing.", "hi": "आगे बढ़ने से पहले कम से कम एक सामग्री जोड़ें।", "mr": "पुढे जाण्यापूर्वी किमान एक साहित्य जोडा."},
    "client.request_completed": {"en": "Request completed.", "hi": "रिक्वेस्ट पूरी हुई।", "mr": "रिक्वेस्ट पूर्ण झाली."},
    "client.save_failed": {"en": "Unable to save this recipe right now.", "hi": "अभी यह रेसिपी सेव नहीं हो सकती।", "mr": "ही रेसिपी आत्ता सेव्ह करता येत नाही."},
    "client.auth_required": {"en": "Please sign up or log in to continue.", "hi": "आगे बढ़ने के लिए साइन अप या लॉगिन करें।", "mr": "पुढे जाण्यासाठी साइन अप किंवा लॉगिन करा."},
    "client.ingredient_voice_started": {"en": "Voice ingredient input is listening."},
    "client.ingredient_voice_stopped": {"en": "Voice ingredient input stopped."},
    "client.ingredient_voice_unsupported": {"en": "Voice ingredient input is not supported in this browser."},
    "client.ingredient_voice_denied": {"en": "Microphone access was blocked. Please allow it in your browser settings to use voice ingredient input."},
    "client.ingredient_voice_added": {"en": "Spoken ingredients were added."},
    "client.ingredient_voice_empty": {"en": "No ingredient words were captured. Please try again."},
    "client.guide_camera_started": {"en": "Live preview is now running.", "hi": "कैमरा overlay अब चालू है।", "mr": "कॅमेरा overlay आता सुरू आहे."},
    "client.guide_camera_stopped": {"en": "Live preview stopped.", "hi": "कैमरा overlay बंद हो गया।", "mr": "कॅमेरा overlay बंद झाला."},
    "client.guide_camera_unsupported": {"en": "This browser does not support live preview for the cooking guide.", "hi": "यह ब्राउज़र cooking camera overlay को support नहीं करता।", "mr": "हा ब्राउझर cooking camera overlay ला support करत नाही."},
    "client.guide_camera_denied": {"en": "Camera access was blocked, so live preview could not start. Please allow it in your browser settings.", "hi": "कैमरा एक्सेस ब्लॉक हो गया। कृपया browser settings में अनुमति दें।", "mr": "कॅमेरा access ब्लॉक झाला. कृपया browser settings मध्ये परवानगी द्या."},
    "client.guide_voice_started": {"en": "Voice assistant is listening for commands.", "hi": "वॉइस असिस्टेंट कमांड सुन रहा है।", "mr": "व्हॉइस असिस्टंट कमांड ऐकत आहे."},
    "client.guide_voice_stopped": {"en": "Voice assistant stopped.", "hi": "वॉइस असिस्टेंट बंद हो गया।", "mr": "व्हॉइस असिस्टंट बंद झाला."},
    "client.guide_voice_unsupported": {"en": "Speech recognition is not supported in this browser.", "hi": "इस ब्राउज़र में speech recognition support नहीं है।", "mr": "या ब्राउझरमध्ये speech recognition support नाही."},
    "client.guide_voice_denied": {"en": "Microphone access was blocked. Please allow it in your browser settings.", "hi": "माइक्रोफोन एक्सेस ब्लॉक हो गया। कृपया browser settings में अनुमति दें।", "mr": "मायक्रोफोन access ब्लॉक झाला. कृपया browser settings मध्ये परवानगी द्या."},
}


INGREDIENT_TRANSLATIONS = {
    "egg": {"hi": "अंडा", "mr": "अंडे"},
    "onion": {"hi": "प्याज", "mr": "कांदा"},
    "tomato": {"hi": "टमाटर", "mr": "टोमॅटो"},
    "chili": {"hi": "मिर्च", "mr": "मिरची"},
    "salt": {"hi": "नमक", "mr": "मीठ"},
    "oil": {"hi": "तेल", "mr": "तेल"},
    "pasta": {"hi": "पास्ता", "mr": "पास्ता"},
    "garlic": {"hi": "लहसुन", "mr": "लसूण"},
    "paneer": {"hi": "पनीर", "mr": "पनीर"},
    "ginger": {"hi": "अदरक", "mr": "आलं"},
    "rice": {"hi": "चावल", "mr": "भात"},
    "carrot": {"hi": "गाजर", "mr": "गाजर"},
    "beans": {"hi": "बीन्स", "mr": "बीन्स"},
    "potato": {"hi": "आलू", "mr": "बटाटा"},
    "chickpea": {"hi": "चना", "mr": "हरभरा"},
    "cucumber": {"hi": "खीरा", "mr": "काकडी"},
    "lemon": {"hi": "नींबू", "mr": "लिंबू"},
}


RECIPE_TRANSLATIONS = {
    "Veggie Omelette": {
        "title": {"hi": "वेजी ऑमलेट", "mr": "व्हेजी ऑम्लेट"},
        "description": {
            "hi": "रोज़मर्रा की सब्जियों वाला झटपट प्रोटीन-भरा नाश्ता।",
            "mr": "दररोजच्या भाज्यांसह झटपट प्रोटीनयुक्त नाश्ता.",
        },
    },
    "Tomato Pasta": {
        "title": {"hi": "टमाटर पास्ता", "mr": "टोमॅटो पास्ता"},
        "description": {
            "hi": "टमाटर, लहसुन और हर्ब्स से बना आरामदायक भोजन।",
            "mr": "टोमॅटो, लसूण आणि हर्ब्ससह तयार केलेले आरामदायी जेवण.",
        },
    },
    "Paneer Masala": {
        "title": {"hi": "पनीर मसाला", "mr": "पनीर मसाला"},
        "description": {
            "hi": "पनीर और सुगंधित मसालों वाली मलाईदार भारतीय करी।",
            "mr": "पनीर आणि सुगंधी मसाल्यांसह क्रीमी भारतीय करी.",
        },
    },
    "Vegetable Fried Rice": {
        "title": {"hi": "वेजिटेबल फ्राइड राइस", "mr": "व्हेजिटेबल फ्राईड राईस"},
        "description": {
            "hi": "बचे हुए चावल और सब्जियों से बनने वाला एक-पैन भोजन।",
            "mr": "उरलेल्या भात आणि भाज्यांपासून बनणारा वन-पॅन डिश.",
        },
    },
    "Potato Stir Fry": {
        "title": {"hi": "आलू स्टर फ्राय", "mr": "बटाटा स्टर फ्राय"},
        "description": {
            "hi": "आलू, प्याज और मिर्च से बना आसान साइड डिश।",
            "mr": "बटाटा, कांदा आणि मिरचीसह तयार होणारी सोपी साईड डिश.",
        },
    },
    "Chickpea Salad": {
        "title": {"hi": "चना सलाद", "mr": "हरभरा सॅलड"},
        "description": {
            "hi": "चना और ताज़ी सब्जियों वाला हेल्दी नो-कुक बाउल।",
            "mr": "हरभरा आणि ताज्या भाज्यांसह हेल्दी नो-कुक बाउल.",
        },
    },
}


VOICE_COMMANDS = {
    "en": {
        "next": ["next step", "next", "continue"],
        "previous": ["previous step", "previous", "go back"],
        "repeat": ["repeat step", "repeat"],
        "ingredients": ["read ingredients", "ingredients"],
        "stop": ["stop voice", "stop guide", "stop"],
    },
    "hi": {
        "next": ["अगला स्टेप", "अगला", "आगे", "next step", "next"],
        "previous": ["पिछला स्टेप", "पिछला", "पीछे", "previous step"],
        "repeat": ["दोहराएं", "फिर से", "repeat"],
        "ingredients": ["इंग्रीडिएंट्स पढ़ो", "सामग्री पढ़ो", "ingredients"],
        "stop": ["रोकें", "बंद करो", "stop"],
    },
    "mr": {
        "next": ["पुढची पायरी", "पुढे", "next step", "next"],
        "previous": ["मागची पायरी", "मागे", "previous step"],
        "repeat": ["परत सांगा", "पुन्हा", "repeat"],
        "ingredients": ["साहित्य वाचा", "ingredients"],
        "stop": ["थांबा", "बंद करा", "stop"],
    },
}


def normalize_language(language: str | None) -> str:
    """Return a supported language code."""

    if language in SUPPORTED_LANGUAGES:
        return language
    return DEFAULT_LANGUAGE


def get_current_language() -> str:
    """Read the active UI language from session storage."""

    return normalize_language(session.get("language"))


def set_current_language(language: str | None) -> str:
    """Persist a validated language choice in the user session."""

    normalized_language = normalize_language(language)
    session["language"] = normalized_language
    session.modified = True
    return normalized_language


def get_speech_locale(language: str | None) -> str:
    """Return the browser speech locale for the given language."""

    normalized_language = normalize_language(language)
    return SUPPORTED_LANGUAGES[normalized_language]["speech_locale"]


def translate_text(key: str, language: str | None = None, **kwargs) -> str:
    """Translate one UI string with English fallback."""

    normalized_language = normalize_language(language)
    translation_entry = TRANSLATIONS.get(key, {})
    text = translation_entry.get(normalized_language) or translation_entry.get(DEFAULT_LANGUAGE) or key
    return text.format(**kwargs) if kwargs else text


def localize_ingredient(name: str, language: str | None = None) -> str:
    """Translate one ingredient label when a localized label exists."""

    normalized_language = normalize_language(language)
    translation_entry = INGREDIENT_TRANSLATIONS.get(name.lower(), {})
    return translation_entry.get(normalized_language, name)


def get_client_messages(language: str | None = None) -> dict:
    """Return translated frontend messages used by `main.js`."""

    normalized_language = normalize_language(language)
    keys = [
        "client.upload_or_type",
        "client.extract_failed",
        "client.request_failed",
        "client.add_ingredient_first",
        "client.request_completed",
        "client.save_failed",
        "client.auth_required",
        "client.ingredient_voice_started",
        "client.ingredient_voice_stopped",
        "client.ingredient_voice_unsupported",
        "client.ingredient_voice_denied",
        "client.ingredient_voice_added",
        "client.ingredient_voice_empty",
        "client.guide_camera_started",
        "client.guide_camera_stopped",
        "client.guide_camera_unsupported",
        "client.guide_camera_denied",
        "client.guide_voice_started",
        "client.guide_voice_stopped",
        "client.guide_voice_unsupported",
        "client.guide_voice_denied",
    ]
    return {key: translate_text(key, normalized_language) for key in keys}


def get_voice_commands(language: str | None = None) -> dict:
    """Return supported voice phrases for the active language."""

    normalized_language = normalize_language(language)
    return deepcopy(VOICE_COMMANDS.get(normalized_language, VOICE_COMMANDS[DEFAULT_LANGUAGE]))


def localize_recipe_payload(payload: dict, language: str | None = None) -> dict:
    """Translate recipe labels, ingredient names, and guide steps for display."""

    normalized_language = normalize_language(language)
    localized_payload = deepcopy(payload)
    original_title = payload.get("title", "")
    recipe_copy = RECIPE_TRANSLATIONS.get(original_title, {})

    localized_payload["title"] = recipe_copy.get("title", {}).get(normalized_language, original_title)
    localized_payload["description"] = recipe_copy.get("description", {}).get(
        normalized_language,
        payload.get("description", ""),
    )
    localized_payload["ingredients"] = [
        localize_ingredient(item, normalized_language)
        for item in payload.get("ingredients", [])
    ]
    localized_payload["matched_ingredients"] = [
        localize_ingredient(item, normalized_language)
        for item in payload.get("matched_ingredients", [])
    ]
    localized_payload["missing_ingredients"] = [
        localize_ingredient(item, normalized_language)
        for item in payload.get("missing_ingredients", [])
    ]

    guide_steps = [
        localize_guide_step(step, normalized_language)
        for step in payload.get("guide_steps", [])
    ]
    localized_payload["guide_steps"] = guide_steps
    localized_payload["instruction_steps"] = [step["instruction"] for step in guide_steps]

    return localized_payload
