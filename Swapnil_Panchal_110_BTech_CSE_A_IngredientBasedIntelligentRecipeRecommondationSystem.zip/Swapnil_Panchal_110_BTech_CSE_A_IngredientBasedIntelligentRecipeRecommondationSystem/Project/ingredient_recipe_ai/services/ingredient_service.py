"""Ingredient cleanup and normalization helpers."""

from __future__ import annotations

import ast
import csv
import json
import re
from collections.abc import Iterable


STOP_WORDS = {
    "",
    "ingredients",
    "ingredient",
    "optional",
    "some",
    "few",
    "little",
    "taste",
    "needed",
    "divided",
    "plus",
    "about",
    "approximately",
    "preferably",
    "available",
}

MEASUREMENT_WORDS = {
    "cup",
    "cups",
    "tbsp",
    "tablespoon",
    "tablespoons",
    "tsp",
    "teaspoon",
    "teaspoons",
    "gram",
    "grams",
    "kg",
    "g",
    "ml",
    "ltr",
    "oz",
    "ounce",
    "ounces",
    "pound",
    "pounds",
    "lb",
    "lbs",
    "pinch",
    "dash",
    "slice",
    "slices",
    "piece",
    "pieces",
    "package",
    "packages",
    "packet",
    "packets",
    "can",
    "cans",
    "jar",
    "jars",
    "sheet",
    "sheets",
    "head",
    "heads",
    "bunch",
    "bunches",
    "sprig",
    "sprigs",
    "stalk",
    "stalks",
    "rib",
    "ribs",
    "clove",
    "cloves",
    "leaf",
    "leaves",
    "inch",
    "inches",
}

PREPARATION_WORDS = {
    "fresh",
    "freshly",
    "dried",
    "ground",
    "chopped",
    "diced",
    "peeled",
    "cored",
    "seeded",
    "sliced",
    "thinly",
    "thickly",
    "roughly",
    "finely",
    "coarsely",
    "minced",
    "crushed",
    "trimmed",
    "halved",
    "quartered",
    "rinsed",
    "drained",
    "softened",
    "melted",
    "warmed",
    "cooked",
    "uncooked",
    "toasted",
    "packed",
    "large",
    "small",
    "medium",
    "fuji",
    "granny",
    "smith",
    "golden",
    "delicious",
    "extra",
    "virgin",
    "whole",
    "flour",
    "low",
    "sodium",
    "reduced",
    "vegetable",
    "boneless",
    "skinless",
    "lean",
    "plain",
    "room",
    "temperature",
    "crosswise",
    "lengthwise",
    "cut",
    "into",
    "half",
    "halves",
    "such",
    "part",
    "only",
    "taste",
}

CONNECTOR_WORDS = {"and", "with", "for", "from", "the", "a", "an"}

TRAILING_COMPOUND_HEADS = {
    "juice",
    "oil",
    "sauce",
    "powder",
    "stock",
    "broth",
    "pepper",
    "salt",
    "vinegar",
    "cheese",
    "cream",
    "milk",
    "bread",
    "butter",
}

PHRASE_EXPANSIONS = {
    "extra virgin olive oil": ["olive oil", "oil"],
    "olive oil": ["olive oil", "oil"],
    "vegetable oil": ["oil"],
    "canola oil": ["oil"],
    "sesame oil": ["sesame oil", "oil"],
    "chicken stock": ["stock"],
    "vegetable stock": ["stock"],
    "chicken broth": ["stock"],
    "vegetable broth": ["stock"],
    "black pepper": ["black pepper", "pepper"],
    "white pepper": ["white pepper", "pepper"],
    "kosher salt": ["salt"],
    "sea salt": ["salt"],
    "lemon juice": ["lemon juice", "lemon"],
    "lime juice": ["lime juice", "lime"],
    "orange juice": ["orange juice", "orange"],
    "bell pepper": ["bell pepper", "pepper"],
    "red pepper": ["bell pepper", "pepper"],
    "green pepper": ["bell pepper", "pepper"],
    "capsicum": ["bell pepper", "pepper"],
    "soy sauce": ["soy sauce"],
    "fish sauce": ["fish sauce"],
    "cream cheese": ["cream cheese", "cheese"],
    "sour cream": ["sour cream", "cream"],
    "coconut milk": ["coconut milk", "milk"],
    "whole milk": ["milk"],
    "heavy cream": ["cream"],
    "baking powder": ["baking powder"],
    "baking soda": ["baking soda"],
    "brown sugar": ["brown sugar", "sugar"],
    "powdered sugar": ["powdered sugar", "sugar"],
    "red onion": ["onion"],
    "yellow onion": ["onion"],
    "green onion": ["spring onion", "onion"],
    "green onions": ["spring onion", "onion"],
    "spring onion": ["spring onion", "onion"],
    "spring onions": ["spring onion", "onion"],
    "scallion": ["spring onion", "onion"],
    "scallions": ["spring onion", "onion"],
    "garlic clove": ["garlic"],
    "garlic cloves": ["garlic"],
    "turkey breast": ["turkey"],
    "chicken breast": ["chicken"],
    "bibb lettuce": ["lettuce"],
    "romaine lettuce": ["lettuce"],
    "whole wheat lavash": ["lavash", "flatbread"],
    "flour tortilla": ["tortilla", "flatbread"],
    "flour tortillas": ["tortilla", "flatbread"],
    "brown lentils": ["lentil"],
    "brown lentil": ["lentil"],
    "green lentils": ["lentil"],
    "green lentil": ["lentil"],
    "french green lentils": ["lentil"],
    "french green lentil": ["lentil"],
    "sweet potato": ["potato"],
    "sweet potatoes": ["potato"],
    "garbanzo bean": ["chickpea"],
    "garbanzo beans": ["chickpea"],
    "coriander leaves": ["coriander"],
}

ALIASES = {
    "tomatoes": "tomato",
    "onions": "onion",
    "potatoes": "potato",
    "chilies": "chili",
    "chiles": "chili",
    "chilli": "chili",
    "chillis": "chili",
    "capsicums": "bell pepper",
    "green chilli": "chili",
    "green chilies": "chili",
    "ladyfinger": "okra",
    "ladyfingers": "okra",
    "bhindi": "okra",
    "ginger garlic paste": "ginger",
    "aubergine": "eggplant",
    "basil leaves": "basil",
}

SORTED_PHRASE_EXPANSIONS = sorted(
    PHRASE_EXPANSIONS.items(),
    key=lambda item: len(item[0]),
    reverse=True,
)

QUANTITY_PREFIX_PATTERN = re.compile(
    r"^\s*(?:\d+(?:/\d+)?|\d+\.\d+|one|two|three|four|five|half|quarter)\b"
)


def _singularize(word: str) -> str:
    """Convert a simple plural word into its singular form."""

    if word.endswith("ies") and len(word) > 4:
        return f"{word[:-3]}y"
    if word.endswith("ves") and len(word) > 4:
        return f"{word[:-3]}f"
    if word.endswith("oes") and len(word) > 4:
        return word[:-1]
    if word.endswith(("ches", "shes", "xes", "zes", "sses")) and len(word) > 4:
        return word[:-2]
    if word.endswith("s") and len(word) > 3 and not word.endswith("ss"):
        return word[:-1]
    return word


def _dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    """Return values once while preserving the input order."""

    ordered: list[str] = []
    seen: set[str] = set()

    for value in values:
        cleaned = value.strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        ordered.append(cleaned)

    return ordered


def _normalize_structured_list_text(text: str) -> str:
    """Tidy a pasted JSON/Python list string before parsing it."""

    candidate = text.strip()
    if candidate.startswith('"[') and candidate.endswith(']"'):
        candidate = candidate[1:-1]
    return candidate.replace('""', '"')


def _parse_structured_ingredient_input(text: str) -> list[str] | None:
    """Parse pasted ingredient arrays copied from CSV or JSON exports."""

    stripped = text.strip()
    if not stripped:
        return []

    candidate = _normalize_structured_list_text(stripped)
    parser_candidates = [candidate]

    repaired_candidate = candidate
    if '", "' in repaired_candidate and not repaired_candidate.startswith("["):
        repaired_candidate = f'["{repaired_candidate}'
    if repaired_candidate.endswith(']"'):
        repaired_candidate = repaired_candidate[:-1]
    if repaired_candidate != candidate:
        parser_candidates.append(repaired_candidate)

    for parser_candidate in parser_candidates:
        if not (
            (parser_candidate.startswith("[") and parser_candidate.endswith("]"))
            or (parser_candidate.startswith("(") and parser_candidate.endswith(")"))
        ):
            continue

        for parser in (json.loads, ast.literal_eval):
            try:
                parsed = parser(parser_candidate)
            except (json.JSONDecodeError, SyntaxError, ValueError):
                continue

            if isinstance(parsed, (list, tuple)):
                return [str(item).strip() for item in parsed if str(item).strip()]

    doubled_quote_candidate = stripped.strip().strip("[]").strip()
    if '""' in doubled_quote_candidate:
        trimmed_candidate = doubled_quote_candidate.strip('"')
        split_items = [
            item.strip().strip('"').strip()
            for item in re.split(r'""\s*,\s*""', trimmed_candidate)
            if item.strip().strip('"').strip()
        ]
        if len(split_items) > 1:
            return split_items

    return None


def _looks_like_simple_comma_list(tokens: list[str]) -> bool:
    """Detect user input such as `tomato, onion, garlic`."""

    if len(tokens) <= 1:
        return False

    if QUANTITY_PREFIX_PATTERN.match(tokens[0]) and len(tokens) > 2:
        return False

    short_token_count = sum(1 for token in tokens if len(token.split()) <= 3)
    return short_token_count >= max(2, len(tokens) - 1)


def coerce_ingredient_values(value: str | Iterable[str] | None) -> list[str]:
    """Turn mixed input forms into a clean list of raw ingredient strings."""

    if value is None:
        return []

    if isinstance(value, (list, tuple, set)):
        raw_items = [str(item).strip() for item in value if str(item).strip()]
        return _dedupe_preserve_order(raw_items)

    text = str(value).strip()
    if not text:
        return []

    structured_items = _parse_structured_ingredient_input(text)
    if structured_items is not None:
        return _dedupe_preserve_order(structured_items)

    if "\n" in text or ";" in text:
        items: list[str] = []
        for line in re.split(r"[\n;]+", text):
            cleaned_line = line.strip()
            if not cleaned_line:
                continue

            nested_items = _parse_structured_ingredient_input(cleaned_line)
            if nested_items is not None:
                items.extend(nested_items)
            else:
                items.append(cleaned_line)

        return _dedupe_preserve_order(items)

    csv_tokens = [token.strip() for token in next(csv.reader([text], skipinitialspace=True)) if token.strip()]
    if _looks_like_simple_comma_list(csv_tokens):
        return _dedupe_preserve_order(csv_tokens)

    if " and " in text.lower() and len(text.split()) <= 8:
        and_tokens = [token.strip() for token in re.split(r"\band\b", text, flags=re.IGNORECASE) if token.strip()]
        if len(and_tokens) > 1:
            return _dedupe_preserve_order(and_tokens)

    return [text]


def _clean_ingredient_segment(value: str) -> str:
    """Remove quantities and punctuation while preserving ingredient words."""

    cleaned = value.lower().strip()
    cleaned = re.sub(r"\([^)]*\)", " ", cleaned)
    cleaned = cleaned.replace("&", " and ")
    cleaned = cleaned.replace("-", " ")
    cleaned = re.sub(r"\b\d+\s*/\s*\d+\b", " ", cleaned)
    cleaned = re.sub(r"\b\d+(?:\.\d+)?\b", " ", cleaned)
    cleaned = re.sub(r"[^a-z\s]", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def _normalize_term(term: str) -> str:
    """Standardize one extracted ingredient token."""

    cleaned = term.lower().strip()
    if not cleaned:
        return ""

    cleaned = ALIASES.get(cleaned, cleaned)
    words = [
        ALIASES.get(_singularize(word), _singularize(word))
        for word in cleaned.split()
        if word not in STOP_WORDS
    ]
    normalized = " ".join(words).strip()
    return ALIASES.get(normalized, normalized)


def _match_phrase_expansion(cleaned_segment: str) -> list[str]:
    """Return stable ingredient terms for well-known multi-word phrases."""

    for phrase, expansions in SORTED_PHRASE_EXPANSIONS:
        if re.search(rf"\b{re.escape(phrase)}\b", cleaned_segment):
            return [_normalize_term(item) for item in expansions]
    return []


def _extract_terms_from_segment(segment: str) -> list[str]:
    """Pull one or more ingredient tokens from a raw ingredient phrase."""

    cleaned_segment = _clean_ingredient_segment(segment)
    if not cleaned_segment:
        return []

    phrase_terms = _match_phrase_expansion(cleaned_segment)
    if phrase_terms:
        return _dedupe_preserve_order([term for term in phrase_terms if term])

    filtered_words = [
        _normalize_term(word)
        for word in cleaned_segment.split()
        if word not in STOP_WORDS
        and word not in MEASUREMENT_WORDS
        and word not in PREPARATION_WORDS
        and word not in CONNECTOR_WORDS
    ]
    filtered_words = [word for word in filtered_words if word]
    if not filtered_words:
        return []

    if len(filtered_words) == 2 and all(word not in TRAILING_COMPOUND_HEADS for word in filtered_words):
        return _dedupe_preserve_order(filtered_words)

    if len(filtered_words) >= 2:
        last_two_words = " ".join(filtered_words[-2:])
        expanded_last_two = _match_phrase_expansion(last_two_words)
        if expanded_last_two:
            return _dedupe_preserve_order([term for term in expanded_last_two if term])

        if filtered_words[-1] in TRAILING_COMPOUND_HEADS:
            return _dedupe_preserve_order([_normalize_term(last_two_words)])

    return [_normalize_term(filtered_words[-1])]


def normalize_ingredient_entry(value: str) -> list[str]:
    """Normalize one raw ingredient entry into stable match terms."""

    whole_terms = _extract_terms_from_segment(value or "")
    if " or " not in (value or "").lower():
        return _dedupe_preserve_order([term for term in whole_terms if term])

    extracted_terms = list(whole_terms)
    segments = re.split(r"\bor\b", value or "", flags=re.IGNORECASE)
    for segment in segments:
        extracted_terms.extend(_extract_terms_from_segment(segment))

    return _dedupe_preserve_order([term for term in extracted_terms if term])


def normalize_ingredient_name(value: str) -> str:
    """Return the primary normalized ingredient name for one input string."""

    normalized_terms = normalize_ingredient_entry(value)
    return normalized_terms[0] if normalized_terms else ""


def normalize_ingredient_list(values: Iterable[str]) -> list[str]:
    """Normalize, deduplicate, and preserve the original order."""

    normalized_items: list[str] = []
    seen: set[str] = set()

    for value in values:
        for normalized in normalize_ingredient_entry(str(value)):
            if not normalized or normalized in STOP_WORDS or normalized in seen:
                continue
            seen.add(normalized)
            normalized_items.append(normalized)

    return normalized_items


def normalize_ingredient_input(value: str | Iterable[str] | None) -> list[str]:
    """Normalize one request/query input regardless of whether it is text or a list."""

    return normalize_ingredient_list(coerce_ingredient_values(value))


def extract_ingredients_from_text(text: str) -> list[str]:
    """Normalize ingredient text entered manually or copied from exported datasets."""

    return normalize_ingredient_input(text)
