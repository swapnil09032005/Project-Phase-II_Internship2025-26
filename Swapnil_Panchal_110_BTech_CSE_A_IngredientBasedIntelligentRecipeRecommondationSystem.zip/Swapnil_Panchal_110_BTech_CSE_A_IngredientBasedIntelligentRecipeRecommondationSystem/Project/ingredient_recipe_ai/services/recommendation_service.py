"""Rule-based fallback ranking logic for ingredient-based recommendation."""

from __future__ import annotations

from functools import lru_cache

from sqlalchemy.orm import joinedload

from models import Recipe
from services.ingredient_service import normalize_ingredient_list

MAX_RECOMMENDATION_RESULTS = 6

def _build_rule_based_summary(recipe: Recipe, selected_ingredients: list[str]) -> dict:
    """Build a lightweight payload for fallback ranking."""

    recipe_ingredients = [ingredient.name for ingredient in recipe.ingredients]
    matched = [item for item in recipe_ingredients if item in selected_ingredients]
    missing = [item for item in recipe_ingredients if item not in selected_ingredients]
    total = len(recipe_ingredients) or 1
    score = round((len(matched) / total) * 100, 2)

    return {
        "id": recipe.id,
        "title": recipe.title,
        "description": recipe.description,
        "cooking_time": recipe.cooking_time,
        "servings": recipe.servings,
        "difficulty": recipe.difficulty,
        "image_url": recipe.image_url,
        "matched_ingredients": matched,
        "missing_ingredients": missing,
        "raw_match_score": score,
        "match_score": score,
    }


@lru_cache(maxsize=1)
def _load_rule_based_catalog() -> tuple[dict, ...]:
    """Load lightweight recipe summaries once for fast fallback ranking."""

    recipes = Recipe.query.options(joinedload(Recipe.ingredients)).all()
    catalog: list[dict] = []

    for recipe in recipes:
        catalog.append(
            {
                "id": recipe.id,
                "title": recipe.title,
                "description": recipe.description,
                "cooking_time": recipe.cooking_time,
                "servings": recipe.servings,
                "difficulty": recipe.difficulty,
                "image_url": recipe.image_url,
                "ingredients": [ingredient.name for ingredient in recipe.ingredients],
            }
        )

    return tuple(catalog)


def recommend_recipes(
    user_ingredients: list[str],
    limit: int = MAX_RECOMMENDATION_RESULTS,
) -> list[dict]:
    """
    Rank recipes based on available ingredients.

    Match score formula:
    matched ingredients / total recipe ingredients * 100
    """

    normalized_ingredients = normalize_ingredient_list(user_ingredients)

    ranked_recipes: list[dict] = []
    for recipe in _load_rule_based_catalog():
        matched = [item for item in recipe["ingredients"] if item in normalized_ingredients]
        missing = [item for item in recipe["ingredients"] if item not in normalized_ingredients]
        score = round((len(matched) / (len(recipe["ingredients"]) or 1)) * 100, 2)
        ranked_recipes.append(
            {
                "id": recipe["id"],
                "title": recipe["title"],
                "description": recipe["description"],
                "cooking_time": recipe["cooking_time"],
                "servings": recipe["servings"],
                "difficulty": recipe["difficulty"],
                "image_url": recipe["image_url"],
                "matched_ingredients": matched,
                "missing_ingredients": missing,
                "raw_match_score": score,
                "match_score": score,
            }
        )

    ranked_recipes.sort(
        key=lambda recipe: (
            -recipe["raw_match_score"],
            len(recipe["missing_ingredients"]),
            recipe["cooking_time"],
        )
    )

    if limit and limit > 0:
        return ranked_recipes[:limit]

    return ranked_recipes
