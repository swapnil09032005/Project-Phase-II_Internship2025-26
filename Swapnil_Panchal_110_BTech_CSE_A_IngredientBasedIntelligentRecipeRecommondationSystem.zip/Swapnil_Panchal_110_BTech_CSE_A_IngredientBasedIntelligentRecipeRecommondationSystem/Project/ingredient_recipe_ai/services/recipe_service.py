"""Recipe helpers used by pages, APIs, and the dashboard."""

from __future__ import annotations

from flask import session
from sqlalchemy.orm import joinedload

from models import Recipe, SavedRecipe, db
from services.guide_service import (
    build_instruction_text,
    generate_guided_cooking_steps,
    generate_guided_cooking_steps_from_instructions,
    serialize_guide_step,
)


def generate_cooking_instructions(recipe_title: str, ingredient_names: list[str]) -> str:
    """Create basic instructions when a recipe does not provide full steps."""

    guide_steps = generate_guided_cooking_steps(recipe_title, ingredient_names)
    return build_instruction_text(guide_steps)


def build_recipe_payload(recipe: Recipe, selected_ingredients: list[str] | None = None) -> dict:
    """Convert a database recipe object into JSON-friendly data."""

    recipe_ingredients = [ingredient.name for ingredient in recipe.ingredients]
    selected_ingredients = selected_ingredients or []

    matched = [item for item in recipe_ingredients if item in selected_ingredients]
    missing = [item for item in recipe_ingredients if item not in selected_ingredients]
    total = len(recipe_ingredients) or 1
    score = round((len(matched) / total) * 100, 2)
    guide_steps = [serialize_guide_step(step) for step in recipe.guide_steps]

    if not guide_steps:
        guide_steps = generate_guided_cooking_steps_from_instructions(
            recipe.instructions,
            recipe.title,
            recipe_ingredients,
        )
    if not guide_steps:
        guide_steps = generate_guided_cooking_steps(recipe.title, recipe_ingredients)

    return {
        "id": recipe.id,
        "title": recipe.title,
        "description": recipe.description,
        "cooking_time": recipe.cooking_time,
        "servings": recipe.servings,
        "difficulty": recipe.difficulty,
        "instructions": recipe.instructions,
        "image_url": recipe.image_url,
        "ingredients": recipe_ingredients,
        "matched_ingredients": matched,
        "missing_ingredients": missing,
        "raw_match_score": score,
        "match_score": score,
        "guide_steps": guide_steps,
        "instruction_steps": [step["instruction"] for step in guide_steps],
    }


def get_recipe_by_id(recipe_id: int) -> Recipe | None:
    """Fetch one recipe together with its ingredients."""

    return (
        Recipe.query.options(joinedload(Recipe.ingredients), joinedload(Recipe.guide_steps))
        .filter_by(id=recipe_id)
        .first()
    )


def get_recipes_by_ids(recipe_ids: list[int]) -> dict[int, Recipe]:
    """Fetch many recipes and return them indexed by id."""

    normalized_ids = [recipe_id for recipe_id in recipe_ids if recipe_id]
    if not normalized_ids:
        return {}

    recipes = (
        Recipe.query.options(joinedload(Recipe.ingredients), joinedload(Recipe.guide_steps))
        .filter(Recipe.id.in_(normalized_ids))
        .all()
    )
    return {recipe.id: recipe for recipe in recipes}


def get_recipe_id_lookup_by_titles(titles: list[str]) -> dict[str, int]:
    """Return a title-to-id lookup for existing recipes."""

    normalized_titles = [title for title in titles if title]
    if not normalized_titles:
        return {}

    recipes = Recipe.query.filter(Recipe.title.in_(normalized_titles)).all()
    return {recipe.title: recipe.id for recipe in recipes}


def save_recipe_for_user(user_id: int, recipe_id: int) -> tuple[bool, str]:
    """Store a bookmark for the user unless it already exists."""

    existing_entry = SavedRecipe.query.filter_by(user_id=user_id, recipe_id=recipe_id).first()
    if existing_entry:
        return False, "Recipe already saved."

    saved_recipe = SavedRecipe(user_id=user_id, recipe_id=recipe_id)
    db.session.add(saved_recipe)
    db.session.commit()
    return True, "Recipe saved successfully."


def _get_recent_recipe_store() -> dict:
    """
    Return the per-user recent recipe store from the session.

    Older versions used a single `recent_recipe_ids` list for the whole browser
    session. The new structure stores recent recipes separately for each user.
    """

    recent_store = session.get("recent_recipe_ids_by_user", {})
    if not isinstance(recent_store, dict):
        recent_store = {}
    return recent_store


def track_recent_recipe(recipe_id: int) -> None:
    """Keep a short list of recently viewed recipe ids for the logged-in user."""

    user_id = session.get("user_id")
    if not user_id:
        return

    recent_store = _get_recent_recipe_store()
    user_key = str(user_id)
    recent_items = recent_store.get(user_key, [])
    filtered_items = [item for item in recent_items if item != recipe_id]
    filtered_items.insert(0, recipe_id)
    recent_store[user_key] = filtered_items[:6]
    session["recent_recipe_ids_by_user"] = recent_store
    session.modified = True


def get_recent_recipes(user_id: int) -> list[Recipe]:
    """Return recently viewed recipes for one logged-in user."""

    recent_store = _get_recent_recipe_store()
    recipe_ids = recent_store.get(str(user_id), [])
    recipes = [get_recipe_by_id(recipe_id) for recipe_id in recipe_ids]
    return [recipe for recipe in recipes if recipe is not None]
