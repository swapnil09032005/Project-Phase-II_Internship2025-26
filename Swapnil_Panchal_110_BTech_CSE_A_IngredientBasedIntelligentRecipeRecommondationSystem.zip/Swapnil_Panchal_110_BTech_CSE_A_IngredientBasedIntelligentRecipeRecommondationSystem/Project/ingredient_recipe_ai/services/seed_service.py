"""Seed helpers for the built-in featured and generated recipe catalog."""

from __future__ import annotations

from sqlalchemy.orm import joinedload

from models import GuideStep, Ingredient, Recipe, db
from services.guide_service import build_instruction_text, generate_guided_cooking_steps


FEATURED_RECIPES = [
    {
        "title": "Veggie Omelette",
        "description": "A quick breakfast omelette with onion, tomato, and bell pepper.",
        "cooking_time": 12,
        "servings": 2,
        "difficulty": "Easy",
        "image_url": "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80",
        "ingredients": ["egg", "onion", "tomato", "bell pepper", "milk", "oil", "salt", "pepper"],
    },
    {
        "title": "Tomato Pasta",
        "description": "Comforting pasta tossed in a tomato garlic sauce for a fast meal.",
        "cooking_time": 25,
        "servings": 3,
        "difficulty": "Easy",
        "image_url": "https://images.unsplash.com/photo-1516100882582-96c3a05fe590?auto=format&fit=crop&w=1200&q=80",
        "ingredients": ["pasta", "tomato", "onion", "garlic", "basil", "oil", "salt"],
    },
    {
        "title": "Paneer Masala",
        "description": "A rich paneer curry with onion, tomato, and warm Indian spices.",
        "cooking_time": 32,
        "servings": 4,
        "difficulty": "Medium",
        "image_url": "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=1200&q=80",
        "ingredients": ["paneer", "tomato", "onion", "garlic", "ginger", "cumin", "oil", "salt"],
    },
    {
        "title": "Vegetable Fried Rice",
        "description": "A one-pan rice dish with vegetables, soy sauce, and quick stir-fry flavor.",
        "cooking_time": 24,
        "servings": 3,
        "difficulty": "Easy",
        "image_url": "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=80",
        "ingredients": ["rice", "carrot", "peas", "bell pepper", "garlic", "soy sauce", "oil", "salt"],
    },
    {
        "title": "Potato Stir Fry",
        "description": "Crisp-edged potatoes cooked with onion and simple skillet spices.",
        "cooking_time": 22,
        "servings": 3,
        "difficulty": "Easy",
        "image_url": "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=1200&q=80",
        "ingredients": ["potato", "onion", "garlic", "chili", "cumin", "oil", "salt"],
    },
    {
        "title": "Chickpea Salad",
        "description": "A fresh chickpea salad with cucumber, onion, tomato, and lemon.",
        "cooking_time": 15,
        "servings": 2,
        "difficulty": "Easy",
        "image_url": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=1200&q=80",
        "ingredients": ["chickpea", "cucumber", "tomato", "onion", "lemon", "coriander", "salt"],
    },
]

CORE_INGREDIENTS = [
    {"name": "paneer", "display": "Paneer", "pairings": ["tomato", "onion", "coriander"]},
    {"name": "chickpea", "display": "Chickpea", "pairings": ["cucumber", "tomato", "lemon"]},
    {"name": "mushroom", "display": "Mushroom", "pairings": ["garlic", "spinach", "thyme"]},
    {"name": "potato", "display": "Potato", "pairings": ["onion", "peas", "cumin"]},
    {"name": "cauliflower", "display": "Cauliflower", "pairings": ["peas", "turmeric", "tomato"]},
    {"name": "spinach", "display": "Spinach", "pairings": ["garlic", "corn", "onion"]},
    {"name": "tofu", "display": "Tofu", "pairings": ["soy sauce", "bell pepper", "spring onion"]},
    {"name": "lentil", "display": "Lentil", "pairings": ["tomato", "cumin", "coriander"]},
    {"name": "corn", "display": "Corn", "pairings": ["bell pepper", "lime", "onion"]},
    {"name": "peas", "display": "Peas", "pairings": ["mint", "onion", "cumin"]},
    {"name": "bell pepper", "display": "Bell Pepper", "pairings": ["onion", "tomato", "garlic"]},
    {"name": "zucchini", "display": "Zucchini", "pairings": ["garlic", "lemon", "basil"]},
    {"name": "cabbage", "display": "Cabbage", "pairings": ["carrot", "spring onion", "soy sauce"]},
    {"name": "broccoli", "display": "Broccoli", "pairings": ["garlic", "sesame", "bell pepper"]},
    {"name": "carrot", "display": "Carrot", "pairings": ["peas", "ginger", "coriander"]},
    {"name": "pumpkin", "display": "Pumpkin", "pairings": ["onion", "garlic", "cinnamon"]},
    {"name": "sweet potato", "display": "Sweet Potato", "pairings": ["onion", "paprika", "lime"]},
    {"name": "black bean", "display": "Black Bean", "pairings": ["corn", "lime", "coriander"]},
    {"name": "egg", "display": "Egg", "pairings": ["onion", "tomato", "pepper"]},
    {"name": "tomato", "display": "Tomato", "pairings": ["onion", "basil", "garlic"]},
]

RECIPE_FORMATS = [
    {
        "name": "Curry",
        "base_minutes": 28,
        "servings": 4,
        "difficulty": "Medium",
        "ingredients": ["onion", "tomato", "garlic", "ginger", "turmeric", "cumin", "oil"],
        "image_url": "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A {style_lower} curry centered on {ingredient_lower} with {accent}.",
    },
    {
        "name": "Stir Fry",
        "base_minutes": 20,
        "servings": 3,
        "difficulty": "Easy",
        "ingredients": ["onion", "garlic", "bell pepper", "soy sauce", "oil"],
        "image_url": "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A quick {style_lower} stir fry that tosses {ingredient_lower} with {accent}.",
    },
    {
        "name": "Pasta",
        "base_minutes": 24,
        "servings": 3,
        "difficulty": "Easy",
        "ingredients": ["pasta", "tomato", "garlic", "basil", "oil"],
        "image_url": "https://images.unsplash.com/photo-1516100882582-96c3a05fe590?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A weeknight pasta that folds {ingredient_lower} into {accent}.",
    },
    {
        "name": "Fried Rice",
        "base_minutes": 22,
        "servings": 3,
        "difficulty": "Easy",
        "ingredients": ["rice", "onion", "garlic", "peas", "soy sauce", "oil"],
        "image_url": "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A fast fried rice with {ingredient_lower}, built on {accent}.",
    },
    {
        "name": "Salad",
        "base_minutes": 16,
        "servings": 2,
        "difficulty": "Easy",
        "ingredients": ["cucumber", "onion", "lemon", "coriander", "oil"],
        "image_url": "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A fresh salad that pairs {ingredient_lower} with {accent}.",
    },
    {
        "name": "Soup",
        "base_minutes": 26,
        "servings": 4,
        "difficulty": "Easy",
        "ingredients": ["onion", "garlic", "pepper", "stock", "oil"],
        "image_url": "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A soothing soup that simmers {ingredient_lower} with {accent}.",
    },
    {
        "name": "Wrap",
        "base_minutes": 18,
        "servings": 2,
        "difficulty": "Easy",
        "ingredients": ["flatbread", "onion", "lettuce", "yogurt", "chili"],
        "image_url": "https://images.unsplash.com/photo-1530469912745-a215c6b256ea?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A handheld wrap that layers {ingredient_lower} with {accent}.",
    },
    {
        "name": "Noodles",
        "base_minutes": 21,
        "servings": 3,
        "difficulty": "Easy",
        "ingredients": ["noodles", "garlic", "soy sauce", "spring onion", "oil"],
        "image_url": "https://images.unsplash.com/photo-1617093727343-374698b1b08d?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A slurp-friendly noodle bowl with {ingredient_lower}, plus {accent}.",
    },
    {
        "name": "Grain Bowl",
        "base_minutes": 19,
        "servings": 2,
        "difficulty": "Easy",
        "ingredients": ["rice", "cucumber", "lemon", "coriander", "yogurt"],
        "image_url": "https://images.unsplash.com/photo-1543332164-6e82f355badc?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A balanced grain bowl that brings together {ingredient_lower} and {accent}.",
    },
    {
        "name": "Skillet",
        "base_minutes": 23,
        "servings": 3,
        "difficulty": "Medium",
        "ingredients": ["onion", "garlic", "pepper", "oil", "coriander"],
        "image_url": "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=1200&q=80",
        "description_template": "A hearty skillet recipe where {ingredient_lower} cooks with {accent}.",
    },
]

STYLE_PROFILES = [
    {"name": "Classic", "ingredients": ["salt", "pepper"], "minute_offset": 0},
    {"name": "Spicy", "ingredients": ["chili", "black pepper"], "minute_offset": 2},
    {"name": "Garlic Herb", "ingredients": ["garlic", "parsley", "oregano"], "minute_offset": 1},
    {"name": "Creamy", "ingredients": ["cream", "butter"], "minute_offset": 3},
    {"name": "Smoky", "ingredients": ["smoked paprika", "roasted garlic"], "minute_offset": 2},
]

GENERATED_RECIPE_COUNT = len(CORE_INGREDIENTS) * len(RECIPE_FORMATS) * len(STYLE_PROFILES)
SEEDED_RECIPE_COUNT = len(FEATURED_RECIPES) + GENERATED_RECIPE_COUNT


def _unique_ingredients(values: list[str]) -> list[str]:
    """Return ingredient names once while preserving their order."""

    ordered: list[str] = []
    seen: set[str] = set()

    for value in values:
        cleaned = value.strip().lower()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        ordered.append(cleaned)

    return ordered


def _format_accent_list(values: list[str]) -> str:
    """Turn a short list into natural display text."""

    cleaned = [value for value in values if value]
    if not cleaned:
        return "simple pantry staples"
    if len(cleaned) == 1:
        return cleaned[0]
    if len(cleaned) == 2:
        return f"{cleaned[0]} and {cleaned[1]}"
    return f"{cleaned[0]}, {cleaned[1]}, and {cleaned[2]}"


def _build_recipe_record(
    title: str,
    description: str,
    cooking_time: int,
    servings: int,
    difficulty: str,
    image_url: str,
    ingredient_names: list[str],
) -> dict:
    """Build the full seed payload for one recipe."""

    guide_steps = generate_guided_cooking_steps(title, ingredient_names)
    return {
        "title": title,
        "description": description,
        "cooking_time": cooking_time,
        "servings": servings,
        "difficulty": difficulty,
        "image_url": image_url,
        "ingredients": ingredient_names,
        "guide_steps": guide_steps,
        "instructions": build_instruction_text(guide_steps),
    }


def build_recipe_catalog() -> list[dict]:
    """Return the complete built-in catalog used for startup seeding."""

    catalog = [
        _build_recipe_record(
            title=recipe["title"],
            description=recipe["description"],
            cooking_time=recipe["cooking_time"],
            servings=recipe["servings"],
            difficulty=recipe["difficulty"],
            image_url=recipe["image_url"],
            ingredient_names=_unique_ingredients(recipe["ingredients"]),
        )
        for recipe in FEATURED_RECIPES
    ]

    for ingredient_index, ingredient in enumerate(CORE_INGREDIENTS):
        for format_index, recipe_format in enumerate(RECIPE_FORMATS):
            for style_index, style in enumerate(STYLE_PROFILES):
                ingredient_names = _unique_ingredients(
                    [
                        ingredient["name"],
                        *ingredient["pairings"],
                        *recipe_format["ingredients"],
                        *style["ingredients"],
                    ]
                )
                accent = _format_accent_list(
                    _unique_ingredients(
                        ingredient["pairings"][:1]
                        + recipe_format["ingredients"][:2]
                        + style["ingredients"][:1]
                    )
                )
                catalog.append(
                    _build_recipe_record(
                        title=f"{style['name']} {ingredient['display']} {recipe_format['name']}",
                        description=recipe_format["description_template"].format(
                            style_lower=style["name"].lower(),
                            ingredient_lower=ingredient["name"],
                            accent=accent,
                        ),
                        cooking_time=recipe_format["base_minutes"]
                        + style["minute_offset"]
                        + ((ingredient_index + format_index + style_index) % 4),
                        servings=recipe_format["servings"] + (ingredient_index % 2),
                        difficulty=recipe_format["difficulty"],
                        image_url=recipe_format["image_url"],
                        ingredient_names=ingredient_names,
                    )
                )

    return catalog


def _get_or_create_ingredient(
    name: str,
    ingredients_by_name: dict[str, Ingredient],
) -> Ingredient:
    """Reuse or create a normalized ingredient record."""

    ingredient = ingredients_by_name.get(name)
    if ingredient is None:
        ingredient = Ingredient(name=name)
        db.session.add(ingredient)
        ingredients_by_name[name] = ingredient
    return ingredient


def _attach_recipe_ingredients(
    recipe: Recipe,
    ingredient_names: list[str],
    ingredients_by_name: dict[str, Ingredient],
) -> None:
    """Attach ingredient records to a recipe instance."""

    recipe.ingredients = [
        _get_or_create_ingredient(name, ingredients_by_name)
        for name in ingredient_names
    ]


def _attach_guide_steps(recipe: Recipe, guide_steps: list[dict]) -> None:
    """Attach structured guide steps to a recipe instance."""

    recipe.guide_steps = [
        GuideStep(
            step_number=step["step_number"],
            title=step["title"],
            instruction=step["instruction"],
            focus_area=step["focus_area"],
            overlay_anchor=step["overlay_anchor"],
            voice_hint=step["voice_hint"],
            translations=step["translations"],
        )
        for step in guide_steps
    ]


def _backfill_missing_guide_steps(recipe: Recipe) -> bool:
    """Create guide steps for recipes that still do not have them."""

    if recipe.guide_steps:
        return False

    ingredient_names = [ingredient.name for ingredient in recipe.ingredients]
    guide_steps = generate_guided_cooking_steps(recipe.title, ingredient_names)
    _attach_guide_steps(recipe, guide_steps)

    if not recipe.instructions:
        recipe.instructions = build_instruction_text(guide_steps)

    return True


def seed_sample_data() -> None:
    """
    Seed the built-in recipe catalog.

    The function is intentionally idempotent:
    - missing recipes are inserted
    - missing images are backfilled
    - missing guide steps are added to older rows
    """

    catalog = build_recipe_catalog()
    ingredients_by_name = {ingredient.name: ingredient for ingredient in Ingredient.query.all()}
    existing_recipes = {
        recipe.title: recipe
        for recipe in Recipe.query.options(
            joinedload(Recipe.ingredients),
            joinedload(Recipe.guide_steps),
        ).all()
    }

    has_changes = False

    for recipe_data in catalog:
        recipe = existing_recipes.get(recipe_data["title"])

        if recipe is None:
            recipe = Recipe(
                title=recipe_data["title"],
                description=recipe_data["description"],
                cooking_time=recipe_data["cooking_time"],
                servings=recipe_data["servings"],
                difficulty=recipe_data["difficulty"],
                instructions=recipe_data["instructions"],
                image_url=recipe_data["image_url"],
            )
            _attach_recipe_ingredients(recipe, recipe_data["ingredients"], ingredients_by_name)
            _attach_guide_steps(recipe, recipe_data["guide_steps"])
            db.session.add(recipe)
            existing_recipes[recipe.title] = recipe
            has_changes = True
            continue

        if not recipe.image_url and recipe_data["image_url"]:
            recipe.image_url = recipe_data["image_url"]
            has_changes = True

        if not recipe.instructions and recipe_data["instructions"]:
            recipe.instructions = recipe_data["instructions"]
            has_changes = True

        if _backfill_missing_guide_steps(recipe):
            has_changes = True

    for recipe in existing_recipes.values():
        if _backfill_missing_guide_steps(recipe):
            has_changes = True

    if has_changes:
        db.session.commit()














