"""Guide-step model used by AR, voice, and multilingual cooking features."""

from __future__ import annotations

from datetime import datetime

from . import db


class GuideStep(db.Model):
    """One structured cooking step attached to a recipe."""

    __tablename__ = "guide_steps"
    __table_args__ = (
        db.UniqueConstraint("recipe_id", "step_number", name="uq_recipe_guide_step"),
    )

    id = db.Column(db.Integer, primary_key=True)
    recipe_id = db.Column(db.Integer, db.ForeignKey("recipes.id"), nullable=False)
    step_number = db.Column(db.Integer, nullable=False)
    title = db.Column(db.String(120), nullable=False)
    instruction = db.Column(db.Text, nullable=False)
    focus_area = db.Column(db.String(80), nullable=False, default="pan")
    overlay_anchor = db.Column(db.String(30), nullable=False, default="center")
    voice_hint = db.Column(db.String(160), nullable=True)
    translations = db.Column(db.JSON, default=dict, nullable=False)
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        server_default=db.func.current_timestamp(),
        nullable=False,
    )

    recipe = db.relationship("Recipe", back_populates="guide_steps")

    def __repr__(self) -> str:
        return f"<GuideStep recipe={self.recipe_id} step={self.step_number}>"
