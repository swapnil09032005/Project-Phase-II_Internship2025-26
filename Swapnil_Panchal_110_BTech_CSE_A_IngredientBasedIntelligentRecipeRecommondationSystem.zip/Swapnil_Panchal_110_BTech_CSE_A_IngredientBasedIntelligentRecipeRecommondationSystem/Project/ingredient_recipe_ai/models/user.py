"""User model for login, signup, and saved recipe features."""

from __future__ import annotations

from datetime import datetime

from . import db


class User(db.Model):
    """Stores user account details."""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        server_default=db.func.current_timestamp(),
        nullable=False,
    )

    saved_recipes = db.relationship(
        "SavedRecipe",
        back_populates="user",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<User {self.email}>"
