"""Recipe-related models, including many-to-many mapping tables."""

from __future__ import annotations

from datetime import datetime

from . import db


class RecipeIngredient(db.Model):
    """
    Bridge table between recipes and ingredients.

    This table is kept explicit instead of using a plain SQLAlchemy table so it
    is easier to explain the many-to-many relationship to examiners.
    """

    __tablename__ = "recipe_ingredients"

    recipe_id = db.Column(db.Integer, db.ForeignKey("recipes.id"), primary_key=True)
    ingredient_id = db.Column(
        db.Integer,
        db.ForeignKey("ingredients.id"),
        primary_key=True,
    )


class SavedRecipe(db.Model):
    """Stores bookmarks created by logged-in users."""

    __tablename__ = "saved_recipes"
    __table_args__ = (db.UniqueConstraint("user_id", "recipe_id", name="uq_user_recipe"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    recipe_id = db.Column(db.Integer, db.ForeignKey("recipes.id"), nullable=False)
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        server_default=db.func.current_timestamp(),
        nullable=False,
    )

    user = db.relationship("User", back_populates="saved_recipes")
    recipe = db.relationship("Recipe", back_populates="saved_entries")


class Recipe(db.Model):
    """Main recipe table used by the recommendation engine."""

    __tablename__ = "recipes"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    cooking_time = db.Column(db.Integer, nullable=False)
    servings = db.Column(db.Integer, default=2, nullable=False)
    difficulty = db.Column(db.String(30), default="Easy", nullable=False)
    instructions = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(255), nullable=True)
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        server_default=db.func.current_timestamp(),
        nullable=False,
    )

    ingredients = db.relationship(
        "Ingredient",
        secondary=RecipeIngredient.__table__,
        backref="recipes",
        lazy="joined",
    )

    saved_entries = db.relationship(
        "SavedRecipe",
        back_populates="recipe",
        cascade="all, delete-orphan",
    )

    guide_steps = db.relationship(
        "GuideStep",
        back_populates="recipe",
        cascade="all, delete-orphan",
        order_by="GuideStep.step_number",
    )

    def __repr__(self) -> str:
        return f"<Recipe {self.title}>"
