"""
Database models package.

This file exports the SQLAlchemy instance and the key model classes so other
parts of the app can import them from one place.
"""

from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

from .guide import GuideStep  # noqa: E402
from .ingredient import Ingredient  # noqa: E402
from .recipe import Recipe, RecipeIngredient, SavedRecipe  # noqa: E402
from .user import User  # noqa: E402
