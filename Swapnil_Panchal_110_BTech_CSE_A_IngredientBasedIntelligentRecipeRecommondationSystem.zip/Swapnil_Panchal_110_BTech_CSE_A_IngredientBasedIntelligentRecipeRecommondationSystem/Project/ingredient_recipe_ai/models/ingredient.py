"""Ingredient model used by the recipe matching engine."""

from __future__ import annotations

from datetime import datetime

from . import db


class Ingredient(db.Model):
    """Stores one normalized ingredient name."""

    __tablename__ = "ingredients"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        server_default=db.func.current_timestamp(),
        nullable=False,
    )

    def __repr__(self) -> str:
        return f"<Ingredient {self.name}>"
