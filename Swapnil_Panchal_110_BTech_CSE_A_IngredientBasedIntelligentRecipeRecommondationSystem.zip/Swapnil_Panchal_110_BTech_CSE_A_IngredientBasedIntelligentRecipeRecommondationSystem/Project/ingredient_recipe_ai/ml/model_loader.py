"""Singleton-style loading for the trained recipe similarity model."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import joblib


logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = PROJECT_ROOT / "ml" / "models"
VECTORIZER_PATH = MODEL_DIR / "vectorizer.pkl"
RECIPE_VECTORS_PATH = MODEL_DIR / "recipe_vectors.pkl"


class ModelNotReadyError(RuntimeError):
    """Raised when model assets have not been trained or are unavailable."""


@dataclass(frozen=True)
class LoadedRecipeModel:
    """Container for all model assets held in memory."""

    vectorizer: Any
    recipe_vectors: Any
    recipe_metadata: list[dict[str, Any]]
    reference_terms: tuple[str, ...]
    metadata: dict[str, Any]


def _validate_model_files() -> None:
    """Ensure the trained files exist before loading."""

    missing_files = [
        str(path)
        for path in (VECTORIZER_PATH, RECIPE_VECTORS_PATH)
        if not path.exists()
    ]

    if missing_files:
        raise ModelNotReadyError(
            "ML model files are missing. Place the dataset in `data/recipes.csv` and run "
            "`python ml/train_model.py` first. Missing files: "
            + ", ".join(missing_files)
        )


@lru_cache(maxsize=1)
def load_model() -> LoadedRecipeModel:
    """Load the trained vectorizer and recipe vectors once."""

    _validate_model_files()
    logger.info("Loading ML recommendation assets from disk")

    vectorizer = joblib.load(VECTORIZER_PATH)
    recipe_payload = joblib.load(RECIPE_VECTORS_PATH)

    if not isinstance(recipe_payload, dict) or "matrix" not in recipe_payload:
        raise ModelNotReadyError(
            "recipe_vectors.pkl is invalid. Retrain the model with `python ml/train_model.py`."
        )

    reference_terms = tuple(
        sorted(
            {
                ingredient
                for recipe in recipe_payload.get("recipes", [])
                for ingredient in recipe.get("normalized_ingredients", [])
                if ingredient
            }
        )
    )

    return LoadedRecipeModel(
        vectorizer=vectorizer,
        recipe_vectors=recipe_payload["matrix"],
        recipe_metadata=recipe_payload.get("recipes", []),
        reference_terms=reference_terms,
        metadata={
            "trained_on_rows": recipe_payload.get("trained_on_rows"),
            "created_at": recipe_payload.get("created_at"),
        },
    )


def load_model_assets() -> LoadedRecipeModel:
    """Backward-compatible alias for the cached model loader."""

    return load_model()


def warm_model_assets() -> None:
    """Backward-compatible best-effort preload helper."""

    try:
        load_model()
    except ModelNotReadyError as exc:
        logger.warning("ML preload skipped: %s", exc)
