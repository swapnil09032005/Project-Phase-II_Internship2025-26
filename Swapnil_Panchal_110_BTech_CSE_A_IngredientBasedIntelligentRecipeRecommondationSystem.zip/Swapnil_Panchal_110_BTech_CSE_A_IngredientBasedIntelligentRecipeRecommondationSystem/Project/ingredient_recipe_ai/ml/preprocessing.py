"""Preprocessing helpers for training and serving the recipe similarity model."""

from __future__ import annotations

import ast
import json
import logging
import re
from difflib import get_close_matches
from pathlib import Path
from typing import Any

import pandas as pd

from services.ingredient_service import normalize_ingredient_list
from services.seed_service import build_recipe_catalog


logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
DATASET_PATH = DATA_DIR / "recipes.csv"
FULL_FORMAT_JSON_PATH = DATA_DIR / "full_format_recipes.json"
CATALOG_EXPORT_PATH = DATA_DIR / "recipes_catalog.json"

REQUIRED_COLUMNS = ("id", "title", "ingredients", "instructions")

SYNONYMS = {
    "tomatoes": "tomato",
    "onions": "onion",
    "potatoes": "potato",
    "chilies": "chili",
    "capsicums": "capsicum",
    "scallion": "spring onion",
    "spring onions": "spring onion",
    "garbanzo bean": "chickpea",
    "garbanzo beans": "chickpea",
    "aubergine": "eggplant",
    "chiles": "chili",
    "red pepper": "bell pepper",
}


def _normalize_text_list(values: list[str]) -> list[str]:
    """Normalize one ingredient list with lightweight synonym support."""

    normalized = normalize_ingredient_list(values)
    return [SYNONYMS.get(item, item) for item in normalized]


def _safe_literal_or_json(value: str) -> Any:
    """Parse a string that may contain JSON or Python list syntax."""

    stripped = value.strip()
    if not stripped:
        return []

    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        try:
            return ast.literal_eval(stripped)
        except (ValueError, SyntaxError):
            return stripped


def _flatten_instruction_parts(parts: list[Any]) -> str:
    """Turn mixed nested instruction data into one readable string."""

    flattened: list[str] = []

    for part in parts:
        if isinstance(part, str):
            cleaned = part.strip()
            if cleaned:
                flattened.append(cleaned)
            continue

        if isinstance(part, dict):
            for key in ("text", "instruction", "directions", "preparation"):
                value = part.get(key)
                if isinstance(value, str) and value.strip():
                    flattened.append(value.strip())
                    break
            continue

        if isinstance(part, list):
            nested_text = _flatten_instruction_parts(part)
            if nested_text:
                flattened.append(nested_text)

    return " ".join(flattened).strip()


def parse_ingredient_field(value: Any) -> list[str]:
    """Parse a raw ingredient cell into a normalized ingredient list."""

    if value is None or (isinstance(value, float) and pd.isna(value)):
        return []

    if isinstance(value, list):
        raw_values = [str(item) for item in value if item is not None]
        return _normalize_text_list(raw_values)

    if isinstance(value, str):
        parsed = _safe_literal_or_json(value)
        if isinstance(parsed, list):
            raw_values = [str(item) for item in parsed if item is not None]
        else:
            raw_values = [
                token.strip()
                for token in value.replace(";", ",").split(",")
                if token.strip()
            ]
        return _normalize_text_list(raw_values)

    return _normalize_text_list([str(value)])


def parse_instruction_field(value: Any) -> str:
    """Parse a raw instruction field into one instruction string."""

    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""

    if isinstance(value, list):
        return _flatten_instruction_parts(value)

    if isinstance(value, dict):
        return _flatten_instruction_parts([value])

    if isinstance(value, str):
        parsed = _safe_literal_or_json(value)
        if isinstance(parsed, list):
            return _flatten_instruction_parts(parsed)
        return value.strip()

    return str(value).strip()


def ingredients_to_text(ingredients: list[str]) -> str:
    """Join normalized ingredients into a vectorizer-friendly text string."""

    return " ".join(ingredients).strip()


def _prepare_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure the training dataframe has the canonical recipe columns."""

    rename_map = {column.lower(): column for column in df.columns}
    normalized_columns = {column: column for column in df.columns}

    for expected in REQUIRED_COLUMNS:
        if expected in df.columns:
            continue
        if expected in rename_map:
            normalized_columns[rename_map[expected]] = expected

    df = df.rename(columns=normalized_columns).copy()

    if "id" not in df.columns:
        df["id"] = range(1, len(df) + 1)

    if "title" not in df.columns:
        raise ValueError("The dataset must contain a title column.")

    if "ingredients" not in df.columns:
        raise ValueError("The dataset must contain an ingredients column.")

    if "instructions" not in df.columns:
        if "directions" in df.columns:
            df["instructions"] = df["directions"]
        else:
            df["instructions"] = ""

    df["title"] = df["title"].fillna("").astype(str).str.strip()
    df["normalized_ingredients"] = df["ingredients"].apply(parse_ingredient_field)
    df["instructions"] = df["instructions"].apply(parse_instruction_field)
    df["ingredients_text"] = df["normalized_ingredients"].apply(ingredients_to_text)

    df = df[df["title"] != ""].copy()
    df = df[df["ingredients_text"] != ""].copy()
    df["id"] = pd.to_numeric(df["id"], errors="coerce").fillna(0).astype(int)

    return df.reset_index(drop=True)


def export_recipes_csv_from_full_format_json(
    dataset_path: Path | None = None,
    json_path: Path | None = None,
) -> Path:
    """Create `recipes.csv` from Kaggle's `full_format_recipes.json` when needed."""

    dataset_path = dataset_path or DATASET_PATH
    json_path = json_path or FULL_FORMAT_JSON_PATH

    if dataset_path.exists():
        return dataset_path

    if not json_path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {dataset_path}. Download the Kaggle dataset and place "
            f"`recipes.csv` there, or copy `full_format_recipes.json` into {DATA_DIR}."
        )

    logger.info("Building %s from %s", dataset_path.name, json_path.name)
    with json_path.open("r", encoding="utf-8") as file_handle:
        raw_records = json.load(file_handle)

    rows: list[dict[str, Any]] = []
    for index, record in enumerate(raw_records, start=1):
        rows.append(
            {
                "id": record.get("id", index),
                "title": record.get("title", ""),
                "ingredients": json.dumps(record.get("ingredients", []), ensure_ascii=False),
                "instructions": json.dumps(record.get("directions", []), ensure_ascii=False),
            }
        )

    dataset_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(dataset_path, index=False)
    return dataset_path


def load_training_dataframe(dataset_path: Path | None = None) -> pd.DataFrame:
    """Load and normalize the ML training dataset."""

    dataset_path = dataset_path or DATASET_PATH
    if not dataset_path.exists():
        dataset_path = export_recipes_csv_from_full_format_json(dataset_path=dataset_path)

    logger.info("Loading training dataset from %s", dataset_path)
    dataframe = pd.read_csv(dataset_path)
    return _prepare_dataframe(dataframe)


def build_application_catalog_dataframe() -> pd.DataFrame:
    """Create the recipe catalog dataframe used by the app itself."""

    catalog = build_recipe_catalog()
    rows: list[dict[str, Any]] = []

    for index, recipe in enumerate(catalog, start=1):
        normalized_ingredients = parse_ingredient_field(recipe.get("ingredients", []))
        rows.append(
            {
                "id": index,
                "title": recipe.get("title", ""),
                "ingredients": recipe.get("ingredients", []),
                "instructions": recipe.get("instructions", ""),
                "normalized_ingredients": normalized_ingredients,
                "ingredients_text": ingredients_to_text(normalized_ingredients),
            }
        )

    return pd.DataFrame(rows)


def _estimate_step_count(instructions: str) -> int:
    """Estimate how many major steps a recipe contains."""

    cleaned = re.sub(r"\s+", " ", instructions or "").strip()
    if not cleaned:
        return 0

    numbered_steps = [
        part.strip()
        for part in re.split(r"(?=\b\d+\.\s)", cleaned)
        if part.strip()
    ]
    if len(numbered_steps) > 1:
        return len(numbered_steps)

    sentence_steps = [
        part.strip()
        for part in re.split(r"(?<=[.!?])\s+", cleaned)
        if part.strip()
    ]
    return len(sentence_steps)


def _estimate_cooking_time(
    ingredient_names: list[str],
    instructions: str,
) -> int:
    """Estimate a reasonable cooking time for imported recipes."""

    step_count = max(_estimate_step_count(instructions), 1)
    ingredient_count = max(len(ingredient_names), 1)
    estimated_minutes = (step_count * 7) + max(ingredient_count // 2, 3)
    return min(max(estimated_minutes, 12), 95)


def _estimate_difficulty(
    ingredient_names: list[str],
    instructions: str,
) -> str:
    """Estimate difficulty from ingredient count and instruction length."""

    step_count = _estimate_step_count(instructions)
    ingredient_count = len(ingredient_names)

    if ingredient_count <= 8 and step_count <= 4:
        return "Easy"
    if ingredient_count <= 14 and step_count <= 7:
        return "Medium"
    return "Hard"


def _build_recipe_description(instructions: str) -> str:
    """Create a short UI-friendly description from the first instruction sentence."""

    cleaned = re.sub(r"\s+", " ", instructions or "").strip()
    if not cleaned:
        return "Recipe imported from the recipe dataset."

    first_sentence = re.split(r"(?<=[.!?])\s+", cleaned, maxsplit=1)[0].strip()
    first_sentence = re.sub(r"^\d+\.\s*", "", first_sentence).strip()
    if len(first_sentence) <= 160:
        return first_sentence
    return f"{first_sentence[:157].rstrip()}..."


def build_runtime_catalog_dataframe() -> pd.DataFrame:
    """Create the runtime recipe catalog, preferring the real dataset when present."""

    if DATASET_PATH.exists() or FULL_FORMAT_JSON_PATH.exists():
        dataset_df = load_training_dataframe().copy()
        dataset_df = dataset_df.drop_duplicates(subset=["title"], keep="first").copy()
        dataset_df["description"] = dataset_df["instructions"].apply(_build_recipe_description)
        dataset_df["cooking_time"] = dataset_df.apply(
            lambda row: _estimate_cooking_time(
                row["normalized_ingredients"],
                row["instructions"],
            ),
            axis=1,
        )
        dataset_df["servings"] = 4
        dataset_df["difficulty"] = dataset_df.apply(
            lambda row: _estimate_difficulty(
                row["normalized_ingredients"],
                row["instructions"],
            ),
            axis=1,
        )
        return dataset_df.reset_index(drop=True)

    return build_application_catalog_dataframe()


def build_query_text(user_ingredients: list[str]) -> str:
    """Normalize a user ingredient list into the serving-time query text."""

    return ingredients_to_text(parse_ingredient_field(user_ingredients))


def apply_fuzzy_ingredient_mapping(
    ingredients: list[str],
    reference_terms: set[str],
    cutoff: float = 0.86,
) -> list[str]:
    """Map close ingredient spellings to known ingredient terms when possible."""

    if not reference_terms:
        return parse_ingredient_field(ingredients)

    normalized = parse_ingredient_field(ingredients)
    mapped: list[str] = []

    for ingredient in normalized:
        if ingredient in reference_terms:
            mapped.append(ingredient)
            continue

        match = get_close_matches(ingredient, list(reference_terms), n=1, cutoff=cutoff)
        mapped.append(match[0] if match else ingredient)

    return parse_ingredient_field(mapped)


def build_missing_ingredient_list(
    recipe_ingredients: list[str],
    user_ingredients: list[str],
) -> list[str]:
    """Return recipe ingredients not covered by the user input."""

    if isinstance(user_ingredients, list):
        normalized_user = [str(item).strip() for item in user_ingredients if str(item).strip()]
    else:
        normalized_user = parse_ingredient_field(user_ingredients)

    if isinstance(recipe_ingredients, list):
        normalized_recipe = [str(item).strip() for item in recipe_ingredients if str(item).strip()]
    else:
        normalized_recipe = parse_ingredient_field(recipe_ingredients)

    user_set = set(normalized_user)
    return [item for item in normalized_recipe if item not in user_set]
