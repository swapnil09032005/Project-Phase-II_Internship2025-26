"""Train the TF-IDF model for the hybrid recipe recommender."""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml.preprocessing import build_runtime_catalog_dataframe, load_training_dataframe


logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)

MODEL_DIR = PROJECT_ROOT / "ml" / "models"
VECTORIZER_PATH = MODEL_DIR / "vectorizer.pkl"
RECIPE_VECTORS_PATH = MODEL_DIR / "recipe_vectors.pkl"


def train_and_save_model() -> None:
    """Train the vectorizer once and persist the catalog vectors to disk."""

    training_df = load_training_dataframe()
    application_df = build_runtime_catalog_dataframe()

    vectorizer = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        min_df=2,
        strip_accents="unicode",
    )
    logger.info("Fitting TF-IDF vectorizer on %s training recipes", len(training_df))
    vectorizer.fit(training_df["ingredients_text"])

    logger.info("Transforming %s application recipes into vectors", len(application_df))
    recipe_vectors = vectorizer.transform(application_df["ingredients_text"])

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(vectorizer, VECTORIZER_PATH)
    joblib.dump(
        {
            "matrix": recipe_vectors,
            "recipes": application_df[
                ["id", "title", "normalized_ingredients", "instructions"]
            ].to_dict(orient="records"),
            "trained_on_rows": len(training_df),
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
        RECIPE_VECTORS_PATH,
    )

    logger.info("Saved vectorizer to %s", VECTORIZER_PATH)
    logger.info("Saved recipe vectors to %s", RECIPE_VECTORS_PATH)


if __name__ == "__main__":
    train_and_save_model()
