"""Simple evaluation helper for inspecting ML and hybrid recommendation quality."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app import create_app
from ml.recommender import get_ml_recommendations
from services.hybrid_recommendation_service import get_recommendations


logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)

SAMPLE_QUERIES = [
    ["tomato", "onion", "garlic"],
    ["paneer", "tomato", "cumin"],
    ["rice", "peas", "carrot"],
    ["chickpea", "cucumber", "lemon"],
]


def run_evaluation() -> None:
    """Print a quick side-by-side view of ML confidence and final hybrid source."""

    app = create_app()
    with app.app_context():
        for query in SAMPLE_QUERIES:
            ml_results = get_ml_recommendations(query)
            hybrid_results = get_recommendations(query)

            logger.info("Query: %s", ", ".join(query))
            logger.info(
                "ML top score: %s",
                ml_results[0]["score"] if ml_results else "no result",
            )
            logger.info(
                "Hybrid source: %s",
                hybrid_results[0].get("source") if hybrid_results else "no result",
            )
            logger.info(
                "Top recipe: %s",
                hybrid_results[0]["name"] if hybrid_results else "no result",
            )


if __name__ == "__main__":
    run_evaluation()
