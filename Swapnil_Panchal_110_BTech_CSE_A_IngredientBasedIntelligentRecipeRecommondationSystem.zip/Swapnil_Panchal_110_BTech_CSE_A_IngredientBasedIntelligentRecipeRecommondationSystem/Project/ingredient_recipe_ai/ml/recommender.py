"""Serving-time ML recommendation helpers."""

from __future__ import annotations

import logging
from typing import Iterable

from sklearn.metrics.pairwise import cosine_similarity

from ml.model_loader import ModelNotReadyError, load_model
from ml.preprocessing import (
    apply_fuzzy_ingredient_mapping,
    build_missing_ingredient_list,
    build_query_text,
)
from services.ingredient_service import normalize_ingredient_list


logger = logging.getLogger(__name__)

DEFAULT_LIMIT = 6
SIMILARITY_WEIGHT = 0.7
OVERLAP_WEIGHT = 0.3
ML_CANDIDATE_MULTIPLIER = 40
MIN_ML_CANDIDATES = 240


def _calculate_overlap_score(
    recipe_ingredients: Iterable[str],
    user_ingredients: list[str] | set[str],
) -> float:
    """Return ingredient-overlap percentage for one recipe."""

    normalized_recipe = [item for item in recipe_ingredients if item]
    if not normalized_recipe:
        return 0.0

    user_set = user_ingredients if isinstance(user_ingredients, set) else set(user_ingredients)
    matched_count = sum(1 for item in normalized_recipe if item in user_set)
    return round((matched_count / len(normalized_recipe)) * 100, 2)


def get_ml_recommendations(user_ingredients: list[str], limit: int = DEFAULT_LIMIT) -> list[dict]:
    """
    Return similarity-based ML recommendations for the current app catalog.

    The TF-IDF vocabulary is trained from `data/recipes.csv`, while the ranked
    recipes are the application's own catalog so the existing recipe pages,
    saved-recipes flow, and dashboard continue to work unchanged.
    """

    normalized_ingredients = normalize_ingredient_list(user_ingredients)
    if not normalized_ingredients:
        return []

    try:
        assets = load_model()
    except ModelNotReadyError:
        raise
    except Exception as exc:
        logger.exception("Unexpected ML model loading failure")
        raise ModelNotReadyError(str(exc)) from exc

    normalized_ingredients = apply_fuzzy_ingredient_mapping(
        normalized_ingredients,
        set(assets.reference_terms),
    )

    query_text = build_query_text(normalized_ingredients)
    if not query_text:
        return []

    query_vector = assets.vectorizer.transform([query_text])
    similarity_scores = cosine_similarity(query_vector, assets.recipe_vectors).ravel()
    if similarity_scores.size == 0:
        return []

    candidate_count = min(
        max(limit * ML_CANDIDATE_MULTIPLIER, MIN_ML_CANDIDATES),
        similarity_scores.size,
    )
    if candidate_count >= similarity_scores.size:
        ranked_indices = similarity_scores.argsort()[::-1]
    else:
        candidate_indices = similarity_scores.argpartition(-candidate_count)[-candidate_count:]
        ranked_indices = candidate_indices[similarity_scores[candidate_indices].argsort()[::-1]]
    user_ingredient_set = set(normalized_ingredients)

    scored_candidates: list[dict] = []
    for index in ranked_indices:
        if index >= len(assets.recipe_metadata):
            continue

        metadata = assets.recipe_metadata[index]
        recipe_title = metadata["title"]
        recipe_id = metadata.get("id")
        if recipe_id is None:
            continue

        similarity_score = round(float(similarity_scores[index]) * 100, 2)
        normalized_recipe_ingredients = metadata.get("normalized_ingredients", [])
        overlap_score = _calculate_overlap_score(
            normalized_recipe_ingredients,
            user_ingredient_set,
        )
        final_score = round(
            (SIMILARITY_WEIGHT * similarity_score)
            + (OVERLAP_WEIGHT * overlap_score),
            2,
        )
        scored_candidates.append(
            {
                "recipe_id": int(recipe_id),
                "name": recipe_title,
                "score": final_score,
                "similarity_score": similarity_score,
                "ingredient_overlap_score": overlap_score,
                "missing_ingredients": build_missing_ingredient_list(
                    normalized_recipe_ingredients,
                    normalized_ingredients,
                ),
                "source": "ml",
            }
        )

    scored_candidates.sort(
        key=lambda item: (
            -item["score"],
            len(item["missing_ingredients"]),
            -item["similarity_score"],
        )
    )
    return scored_candidates[:limit]
