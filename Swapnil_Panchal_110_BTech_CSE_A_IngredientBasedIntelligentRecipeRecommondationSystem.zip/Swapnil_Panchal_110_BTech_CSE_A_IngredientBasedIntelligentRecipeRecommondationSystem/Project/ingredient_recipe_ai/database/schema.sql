-- Fresh MySQL schema for the current Ingredient Recipe AI application.
-- This script resets the configured MySQL database and recreates only the
-- tables required by the current Flask app.
--
-- Active database from .env:
--   ingredient_recipe
--
-- Note:
-- - Running this script deletes existing MySQL data in ingredient_recipe.
-- - The Flask app repopulates recipe data on startup via Python services.

DROP DATABASE IF EXISTS ingredient_recipe;
CREATE DATABASE ingredient_recipe
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE ingredient_recipe;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    cooking_time INT NOT NULL,
    servings INT NOT NULL DEFAULT 2,
    difficulty VARCHAR(30) NOT NULL DEFAULT 'Easy',
    instructions TEXT NOT NULL,
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE ingredients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE recipe_ingredients (
    recipe_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    PRIMARY KEY (recipe_id, ingredient_id),
    CONSTRAINT fk_recipe_ingredients_recipe
        FOREIGN KEY (recipe_id) REFERENCES recipes(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_recipe_ingredients_ingredient
        FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE saved_recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    recipe_id INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_user_recipe UNIQUE (user_id, recipe_id),
    CONSTRAINT fk_saved_recipes_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_saved_recipes_recipe
        FOREIGN KEY (recipe_id) REFERENCES recipes(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE guide_steps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id INT NOT NULL,
    step_number INT NOT NULL,
    title VARCHAR(120) NOT NULL,
    instruction TEXT NOT NULL,
    focus_area VARCHAR(80) NOT NULL DEFAULT 'pan',
    overlay_anchor VARCHAR(30) NOT NULL DEFAULT 'center',
    voice_hint VARCHAR(160) NULL,
    translations JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_recipe_guide_step UNIQUE (recipe_id, step_number),
    CONSTRAINT fk_guide_steps_recipe
        FOREIGN KEY (recipe_id) REFERENCES recipes(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_recipes_title ON recipes(title);
CREATE INDEX idx_ingredients_name ON ingredients(name);
CREATE INDEX idx_saved_recipes_user_id ON saved_recipes(user_id);
CREATE INDEX idx_saved_recipes_recipe_id ON saved_recipes(recipe_id);
CREATE INDEX idx_guide_steps_recipe_id ON guide_steps(recipe_id);
CREATE INDEX idx_guide_steps_step_number ON guide_steps(step_number);
